package com.example.mercado.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mercado.Dtos.Requests.FacturaRequestDto;
import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.FacturaResponseDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.models.Factura;
import com.example.mercado.services.FacturaService;
import com.fasterxml.jackson.databind.JsonNode;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("/Mercado/Factura")
@RequiredArgsConstructor
public class FacturaRestController {
  private final FacturaService facturaService;

  
    @Operation(summary = "Operacion para obtener todas las facturas")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Devuelve una lista de json con todas las facturas",
            content = @Content(schema = @Schema(implementation = Factura.class))
    )
  @GetMapping
  public ResponseEntity<List<FacturaResponseDto>> getAllFacturas() {
    return ResponseEntity.ok(facturaService.getAllFacturas());
  }

    @Operation(summary = "Operacion para obtener una factura por id")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Devuelve la factura con el id especificado",
            content = @Content(schema = @Schema(implementation = FacturaResponseDto.class))
    )
  @GetMapping("/{id}")
  public ResponseEntity<FacturaResponseDto> getFacturaById(@PathVariable Long id) {
    FacturaResponseDto factura = facturaService.getFacturaById(id);
    if (factura == null) {
      return ResponseEntity.notFound().build(); // 404 Not Found
    }
    return ResponseEntity.ok(factura); // 200 OK
  }

  // Recuerda que solo puedes crear facturas de ordenes que no tengan una factura
  // asociada
  
  @Operation(summary = "Operacion praa crear una factura")
  @io.swagger.v3.oas.annotations.parameters.RequestBody(
          description = "Introduce los datos de la factura para crearla",
          content = @Content(schema = @Schema(implementation = FacturaRequestDto.class))
  )
  @PostMapping
  public ResponseEntity<FacturaResponseDto> createFactura(@Valid @RequestBody FacturaRequestDto facturaRequestDto) {
    FacturaResponseDto newfactura = facturaService.createFactura(facturaRequestDto);
    return ResponseEntity.status(HttpStatus.CREATED).body(newfactura);
  }

  @Operation(summary = "Operacoin para modificar una factura")
  @io.swagger.v3.oas.annotations.parameters.RequestBody(
          description = "Introduce los datos a modificar de la factura",
          content = @Content(schema = @Schema(implementation = FacturaRequestDto.class))
  )
  @PatchMapping({ "/{id}" })
  public ResponseEntity<FacturaResponseDto> updatedFactura(@PathVariable Long id,
      @RequestBody JsonNode jsonNode) {
    FacturaResponseDto updatedFactura = facturaService.updatedFactura(id,
        jsonNode);
    return ResponseEntity.status(HttpStatus.CREATED).body(updatedFactura);
  }

  @Operation(summary = "Operacion para eliminar una factura")
  @io.swagger.v3.oas.annotations.parameters.RequestBody(
          description = "Introduce el id de la factura que quieres eliminar"
  )
  @DeleteMapping("/{id}")
  public ResponseEntity<Void> deleteFactura(@PathVariable Long id) {
    facturaService.deleteFacturaById(id);
    return ResponseEntity.noContent().build();
  }

}
