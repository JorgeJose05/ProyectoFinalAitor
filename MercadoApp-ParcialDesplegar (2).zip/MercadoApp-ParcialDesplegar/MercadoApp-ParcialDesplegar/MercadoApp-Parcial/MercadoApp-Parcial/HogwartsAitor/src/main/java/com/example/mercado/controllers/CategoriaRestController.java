package com.example.mercado.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mercado.Dtos.Requests.CategoriaRequestDto;
import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.CategoriaResponseDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.models.Categoria;
import com.example.mercado.services.CategoriaService;
import com.fasterxml.jackson.databind.JsonNode;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("/Mercado/Categorias")
@RequiredArgsConstructor
public class CategoriaRestController {
    private final CategoriaService categoriaService;

    @GetMapping
    @Operation(summary = "Muestra todas las categorias")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "JSON con los datos del profesor a modificar. Todos los campos son opcionales.", content = @Content(schema = @Schema(implementation = Categoria.class)))
    public ResponseEntity<List<CategoriaResponseDto>> getAllCategorias() {
        return ResponseEntity.ok(categoriaService.getAllCategorias());
    }

    @Operation(summary = "Muestra una categoria con el id specificado")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Este es un ejemplo de el json de una categoria", content = @Content(schema = @Schema(implementation = CategoriaResponseDto.class)))
    @GetMapping("/{id}")
    public ResponseEntity<CategoriaResponseDto> getCategoriaById(@PathVariable Long id) {
        CategoriaResponseDto categoria = categoriaService.getCategoriaById(id);
        if (categoria == null) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
        return ResponseEntity.ok(categoria); // 200 OK
    }

    @Operation(summary = "Operacion para crear una categoria")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Intoduce los datos de una catgeoria para crearla", content = @Content(schema = @Schema(implementation = CategoriaRequestDto.class)))
    @PostMapping
    public ResponseEntity<CategoriaResponseDto> createCategoria(
            @Valid @RequestBody CategoriaRequestDto categoriaRequestDto) {
        CategoriaResponseDto newCategoria = categoriaService.createCategoria(categoriaRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(newCategoria);
    }

    @Operation(summary = "Operacion para modificar una categoria")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Intoduce los datos de una catgeoria para modificarla y su id", content = @Content(schema = @Schema(implementation = CategoriaRequestDto.class)))
    @PatchMapping({ "/{id}" })
    public ResponseEntity<CategoriaResponseDto> updatedCategoria(@PathVariable Long id,
            @RequestBody JsonNode jsonNode) {
        CategoriaResponseDto updatedCategoria = categoriaService.updateCategoria(id,
                jsonNode);
        return ResponseEntity.status(HttpStatus.CREATED).body(updatedCategoria);
    }

    @Operation(summary = "Operacion para eliminar una catgeoria")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Introduce el id de una categoria para eliminarla")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategoria(@PathVariable Long id) {
        categoriaService.deleteCategoria(id);
        return ResponseEntity.noContent().build();
    }
}
