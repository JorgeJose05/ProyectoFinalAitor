package com.example.mercado.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mercado.models.Factura;

public interface FacturaRepository extends JpaRepository<Factura, Long> {
    
}
