package com.example.mercado.Dtos.Responses;

import java.time.LocalDateTime;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Modelo dto de la orden")
@Data
public class OrdenResponseDto {
    @Schema(description = "Id de la orden", example = "1")
    private Long id;
    @Schema(description = "Fecha de la orden", example = "2023-10-01T12:00:00")
    private LocalDateTime fecha;
    @Schema(description = "Estado de la orden", example = "Enviado")
    private String estado;

    @Schema(description = "Total de la orden", example = "100.50")
    private Double total;

    @Schema(description = "ID del cliente", example = "10")
    private Long clienteId;
    @Schema(description = "ID de la factura", example = "10")
    private Long facturaId;
    @Schema(description = "Lista de IDs de las compras relacionadas")
    private List<Long> comprasIds; // Solo devuelve los IDs de las compras


}
