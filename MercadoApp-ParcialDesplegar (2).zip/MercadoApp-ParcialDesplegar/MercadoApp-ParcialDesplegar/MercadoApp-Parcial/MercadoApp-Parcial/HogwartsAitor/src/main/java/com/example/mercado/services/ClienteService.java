package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.models.Cliente;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

public interface ClienteService {
    List<ClienteResoponseDto> getAllClientes();
    ClienteResoponseDto getClienteById(Long id);
    ClienteResoponseDto createCliente(ClienteRequestDto clienteRequestDto);
    ClienteResoponseDto updateCliente(Long id, JsonNode clientePatchRequestDto);
    void deleteCliente(Long id);
}
