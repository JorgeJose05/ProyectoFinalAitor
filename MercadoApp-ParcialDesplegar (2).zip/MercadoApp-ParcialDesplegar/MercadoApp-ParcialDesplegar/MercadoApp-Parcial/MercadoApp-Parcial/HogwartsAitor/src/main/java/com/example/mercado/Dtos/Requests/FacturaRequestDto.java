package com.example.mercado.Dtos.Requests;

import lombok.Data;

import java.time.LocalDateTime;

import jakarta.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
@Schema(description = "Modelo para hacer request de una factura")
@Data
public class FacturaRequestDto {
    
    @Schema(description = "El total de la factura", example = "100.0", required = true)
    @NotNull(message = "El total es obligatorio")
    @Min(value = -1, message = "El total no puede ser negativo")
    private Double total;

    @Schema(description = "La fecha de emisión de la factura", example = "2021-12-12T12:00:00", required = true)
    @NotNull(message = "La fecha de emisión es obligatoria")
    private LocalDateTime fecha_emision;

    @Schema(description = "El id de la orden asociada a la factura", example = "1", required = true)
    @NotNull(message = "El id de la orden es obligatorio")
    private Long ordenId;

}
