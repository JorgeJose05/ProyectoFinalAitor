package com.example.mercado.mappers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.example.mercado.Dtos.Requests.CategoriaRequestDto;
import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.CategoriaResponseDto;
import com.example.mercado.models.Categoria;
import com.example.mercado.models.Cliente;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class CategoriaMapper {
     public CategoriaResponseDto toDto(Categoria categoria) {
        if (categoria == null) {
        return null;
        }
        CategoriaResponseDto dto = new CategoriaResponseDto();
       
        dto.setId(categoria.getId());
       
        dto.setNombre(categoria.getNombre());
        dto.setDescripcion(categoria.getDescripcion());

        dto.setProductoNombres(categoria.getProductos().stream()
        .map(s -> s.getProducto().getNombre()).toList());

        return dto;

    }


    public Categoria toEntity(CategoriaRequestDto dto) {
        Categoria categoria = new Categoria();

        categoria.setNombre(dto.getNombre());
        categoria.setDescripcion(dto.getDescripcion());
        categoria.setProductos(new ArrayList<>());
        
        return categoria;
        }

        public void updateEntityFromDto(JsonNode patchJson, Categoria categoria) {
        Map<String, String> errores = new HashMap<>();

        patchJson.fieldNames().forEachRemaining(campo -> {
            switch (campo) {
                case "nombre":
                    if (patchJson.get("nombre").isNull()) {
                        errores.put("nombre", "El campo 'nombre' no puede ser null");
                    } else {
                        String nombre = patchJson.get("nombre").asText();
                        if (nombre.isEmpty()) {
                            errores.put("nombre", "El campo 'nombre' no puede estar en blanco");
                        }
                        if (nombre.length() > 50) {
                            errores.put("nombre", "El campo 'nombre' no puede superar los 50 caracteres");
                        }
                        categoria.setNombre(nombre);
                    }
                    break;

                case "descripcion":
                    if (patchJson.get("descripcion").isNull()) {
                        errores.put("descripcion", "El campo 'descripcion' no puede ser null");
                    } else {
                        String descripcion = patchJson.get("descripcion").asText();
                        if (descripcion.isEmpty()) {
                            errores.put("descripcion", "El campo 'descripcion' no puede estar en blanco");
                        }
                        if (descripcion.length() > 255) {
                            errores.put("descripcion", "El campo 'descripcion' no puede superar los 255 caracteres");
                        }
                        categoria.setDescripcion(descripcion);
                    }
                    break;

                default:
                    errores.put(campo, "Campo no reconocido: " + campo);
                    break;
            }
        });

        if (!errores.isEmpty()) {
            throw new IllegalArgumentException("Errores en la actualización: " + errores);
        }
    }

}
