package com.example.mercado.mappers;

import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Orden;
import com.example.mercado.models.OrdenProducto;
import com.example.mercado.repositories.ClienteRespository;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class OrdenMapper {
   final ClienteRespository clienteRepository;


    public OrdenResponseDto toDto(Orden orden) {
        if (orden == null) {
        return null;
        }
        OrdenResponseDto dto = new OrdenResponseDto();
        
        dto.setId(orden.getId());
        dto.setFecha(orden.getFecha());
        dto.setClienteId(orden.getCliente().getId());
        dto.setTotal(orden.getTotal());
        dto.setEstado(orden.getEstado());
        dto.setComprasIds(orden.getCompras().stream()
            .map(compra -> compra.getProducto().getId()).toList()); 

       
        return dto;

    }

public Orden toEntity(OrdenRequestDto dto) {
        Cliente cliente = clienteRepository.findById(dto.getClienteId())
        .orElseThrow(() -> new NoSuchElementException("Cliente no encontrado"));

        Orden orden = new Orden();

        
        orden.setTotal(dto.getTotal());
        orden.setEstado(dto.getEstado());
        orden.setFecha(dto.getFecha());
        orden.setCompras(new ArrayList<>());
        //se pondra null por defecto orden.setFactura(null);
        orden.setCliente(cliente);
        
        cliente.getOrdenes().add(orden);
       
        clienteRepository.save(cliente);

        return orden;
        }

public void updateEntityFromDto(JsonNode patchJson, Orden orden) {
        Map<String, String> errores = new HashMap<>();
        patchJson.fieldNames().forEachRemaining(campo -> {
            switch (campo) {

                case "total":
                    if (patchJson.get("total").isNull()) {
                        errores.put("total", "El campo 'total' no puede ser null");
                    } else {
                        double total = patchJson.get("total").asDouble();
                        if (total < 0)
                            errores.put("total", "El campo 'total' no puede ser negativo");
                        orden.setTotal(total);
                    }
                    break;
                case "fecha":
                    if (patchJson.get("fecha").isNull()) {
                        errores.put("fecha", "El campo 'fecha' no puede ser null");
                    } else {
                        try {
                            LocalDateTime fecha = LocalDateTime.parse(patchJson.get("fecha").asText());
                            orden.setFecha(fecha);
                        } catch (Exception e) {
                            errores.put("fecha", "Formato de fecha inválido. Debe ser ISO-8601.");
                        }
                    }
                    break;
                case "estado":
                    if (patchJson.get("estado").isNull()) {
                        errores.put("estado", "El campo 'estado' no puede ser null");
                    } else {
                        String estado = patchJson.get("estado").asText();
                        if (estado.isEmpty()) {
                            errores.put("estado", "El campo 'estado' no puede estar vacío");
                        }
                        if (estado.length() > 50) {
                            errores.put("estado", "El campo 'estado' no puede superar los 50 caracteres");
                        }
                        orden.setEstado(estado);
                    }
                    break;
                case "clienteId":
                    if (patchJson.get("clienteId").isNull()) {
                        errores.put("clienteId", "El campo 'clienteId' no puede ser null");
                    } else {
                        Long clienteId = patchJson.get("clienteId").asLong();
                        Cliente cliente = clienteRepository.findById(clienteId)
                                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado con ID: " + clienteId));
                        orden.setCliente(cliente);
                    }
                    break;

                default:
                    errores.put(campo, "Campo no reconocido: " + campo);
                    break;
               
            }
        });
        if (!errores.isEmpty()) {
            throw new IllegalArgumentException(String.valueOf(errores));
        }
    }

}

