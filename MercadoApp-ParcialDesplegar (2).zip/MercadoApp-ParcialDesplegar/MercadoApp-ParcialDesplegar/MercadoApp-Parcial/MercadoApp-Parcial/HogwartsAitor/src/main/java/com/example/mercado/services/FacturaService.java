package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.FacturaRequestDto;
import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.FacturaResponseDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.models.Factura;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

public interface FacturaService {
    List<FacturaResponseDto> getAllFacturas();
    
    FacturaResponseDto getFacturaById(Long id);
    
    FacturaResponseDto createFactura(FacturaRequestDto facturaRequestDto);
    FacturaResponseDto updatedFactura(Long id, JsonNode facturaPatchRequestDto);
    void deleteFacturaById(Long id);
}
