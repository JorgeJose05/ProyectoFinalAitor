package com.example.mercado.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.mappers.OrdenMapper;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Orden;
import com.example.mercado.services.OrdenService;
import com.fasterxml.jackson.databind.JsonNode;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("/Mercado/Orden")
@RequiredArgsConstructor
public class OrdenRestController {
    private final OrdenService ordenService;
    private final OrdenMapper ordenMapper;

    @Operation(summary = "Operacion para obtener todas las ordenes")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Devuelve una lista de ordenes",
            content = @Content(schema = @Schema(implementation = Orden.class))
    )
    @GetMapping
    public ResponseEntity<List<OrdenResponseDto>> getAllOrdens() {
        return ResponseEntity.ok(ordenService.getAllOrdens());
    }

    @Operation(summary = "Operacion para obtener una orden por id")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce el id de la orden que quieres obtener",
            content = @Content(schema = @Schema(implementation = OrdenResponseDto.class))
    )
    @GetMapping("/{id}")
    public ResponseEntity<OrdenResponseDto> getOrdenById(@PathVariable Long id) {
        OrdenResponseDto orden = ordenService.getOrdenById(id);
        if (orden == null) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
        return ResponseEntity.ok(orden); // 200 OK
    }

    @Operation(summary = "Operacion para crear una orden")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce todos los campos de la orden que quieres crear",
            content = @Content(schema = @Schema(implementation = OrdenRequestDto.class))
    )
    @PostMapping
    public ResponseEntity<OrdenResponseDto> createOrden(@Valid @RequestBody OrdenRequestDto ordenRequestDto) {
        OrdenResponseDto newOrden = ordenService.createOrden(ordenRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(newOrden);
    }

    @Operation(summary = "Operacion para modificar una orden")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce los campose que quieres modificar de la orden",
            content = @Content(schema = @Schema(implementation = OrdenRequestDto.class))
    )
    @PatchMapping({ "/{id}" })
    public ResponseEntity<OrdenResponseDto> updatedCliente(@PathVariable Long id,
            @RequestBody JsonNode jsonNode) {
        OrdenResponseDto updatedOrden = ordenService.updatedOrden(id,
                jsonNode);
        return ResponseEntity.status(HttpStatus.CREATED).body(updatedOrden);
    }

    @Operation(summary = "Operacion para eliminar una orden")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce una orden que quieras eliminar"
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrden(@PathVariable Long id) {
        ordenService.deleteOrdenById(id);
        return ResponseEntity.noContent().build();
    }

}