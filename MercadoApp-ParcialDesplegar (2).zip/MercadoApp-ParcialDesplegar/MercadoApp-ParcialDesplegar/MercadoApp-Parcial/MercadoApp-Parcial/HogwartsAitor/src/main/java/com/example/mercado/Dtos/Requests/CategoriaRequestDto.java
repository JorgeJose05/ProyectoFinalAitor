package com.example.mercado.Dtos.Requests;

import jakarta.validation.constraints.*;
import lombok.Data;

import io.swagger.v3.oas.annotations.media.Schema;
@Schema(description = "Modelo para hacer request de una categoria")
@Data
public class CategoriaRequestDto {
    @Schema(description = "Nombre de la categoria", example = "Hogar")
    @NotNull(message = "El nombre es obligatorio")
    @NotBlank(message = "El nombre no puede estar vacío")
    @Size(max = 50, message = "El nombre no puede superar los 50 caracteres")
    private String nombre;

    @Schema(description = "Descripcion de la categoria", example = "Productos para el hogar")
    @NotNull(message = "La descripcion es obligatoria")
    @Size(max = 50, message = "La descripcion no puede superar los 50 caracteres")
    @NotBlank(message = "La descripcion no puede estar vacía")
    private String descripcion;


}
