package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ProductoRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.ProductoResponseDto;
import com.example.mercado.mappers.ProductoMapper;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Producto;
import com.example.mercado.repositories.ProductoRepository;
import com.fasterxml.jackson.databind.JsonNode;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class ProductoServiceImp implements ProductoService{
    private ProductoRepository productoRepository;
    private ProductoMapper productoMapper;

    @Autowired
    public ProductoServiceImp(ProductoRepository productoRepository, ProductoMapper productoMapper){
        this.productoRepository = productoRepository;
        this.productoMapper = productoMapper;
    }
    @Override
    public List<ProductoResponseDto> getAllProductos() {
    List<Producto> productos = productoRepository.findAll();
        return productos.stream().map(productoMapper::toDto).toList();
    }

    @Override
    public ProductoResponseDto getProductoById(Long id) {
        Producto producto = productoRepository.findById(id).orElse(null);
        return productoMapper.toDto(producto);
    }
    @Override
    public ProductoResponseDto createProducto(ProductoRequestDto productoRequestDto) {
       
        Producto producto = productoMapper.toEntity(productoRequestDto);
        Producto savedProducto = productoRepository.save(producto);
        return productoMapper.toDto(savedProducto); }
    @Override
    public ProductoResponseDto updateProducto(Long id, JsonNode productoPatchRequestDTO) {
      
        Producto producto = productoRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Estudiante no encontrado con id: " + id));
        
        productoMapper.updateEntityFromDto(productoPatchRequestDTO, producto);
        Producto updatedProducto = productoRepository.save(producto);
        return productoMapper.toDto(updatedProducto);
    }

    @Override
    @Transactional
    public void deleteProducto(Long id) {
        Producto producto = productoRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Estudiante no encontrado con id: " + id));
        productoRepository.delete(producto);
    }
    @Override
    public List<ProductoResponseDto> getProductosCaros(Double precioMinimo) {
        List<Producto> productos = productoRepository.findByPrecioGreaterThan(precioMinimo);
        return productos.stream().map(productoMapper::toDto).collect(Collectors.toList());
    }

}
