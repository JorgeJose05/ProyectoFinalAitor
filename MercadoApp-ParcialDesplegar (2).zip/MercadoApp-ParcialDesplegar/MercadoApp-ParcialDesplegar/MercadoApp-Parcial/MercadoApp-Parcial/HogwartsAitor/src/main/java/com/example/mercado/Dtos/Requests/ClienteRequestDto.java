package com.example.mercado.Dtos.Requests;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.*;
import lombok.Data;

import io.swagger.v3.oas.annotations.media.Schema;
@Schema(description = "Modelo para hacer request de un cliente")
@Data
public class ClienteRequestDto {
    @Schema(description = "Nombre del cliente", example = "Juan")
    @NotNull(message = "El nombre es obligatorio")
    @NotBlank(message = "El nombre no puede estar vacío")
    @Size(max = 50, message = "El nombre no puede superar los 50 caracteres")
    private String nombre;

        @Schema(description = "Email del cliente", example = "juan@gmail.com")
    @NotNull(message = "El email es obligatorio")
    @NotBlank(message = "El email no puede estar vacío")
    @Size(max = 50, message = "El email no puede superar los 50 caracteres")
    private String email;

    @Schema(description = "Password del cliente", example = "password")
    @NotNull(message = "El password es obligatorio")
    @NotBlank(message = "El password no puede estar vacío")
    @Size(max = 50, message = "El password no puede superar los 50 caracteres")
    private String password;

    @Schema(description = "Direccion del cliente", example = "Calle falsa 123")
    @NotNull(message = "La direccion es obligatoria")
    @NotBlank(message = "La direccion no puede estar vacía")
    @Size(max = 50, message = "La direccion no puede superar los 50 caracteres")
    private String direccion;

    @Schema(description = "Telefono del cliente", example = "123456789")
    @NotNull(message = "El telefono es obligatorio")
    @NotBlank(message = "El telefono no puede estar vacío")
    @Size(max = 50, message = "El telefono no puede superar los 50 caracteres")
    private String telefono;
}
