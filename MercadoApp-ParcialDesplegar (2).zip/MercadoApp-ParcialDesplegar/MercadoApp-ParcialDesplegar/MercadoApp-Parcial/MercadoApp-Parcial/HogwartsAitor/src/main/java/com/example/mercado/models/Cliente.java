package com.example.mercado.models;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Modelo de Cliente")
@Entity
@Data
@Table(name = "Cliente")
public class Cliente {
    @Schema(description = "Identificador del cliente", example = "1", required = true)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Schema(description = "Nombre del cliente", example = "Juan Perez", required = true)
    private String nombre;
    @Schema(description = "Email del cliente", example = "juan@gmail.com", required = true)
    private String email;
    @Schema(description = "Email del cliente", example = "1234asdf1234", required = true)
    private String password;
    @Schema(description = "Fecha de nacimiento del cliente", example = "1990-01-01", required = true)
    private String direccion;
    @Schema(description = "Telefono del cliente", example = "123456789", required = true)
    private String telefono;

    @Schema(description = "Ordenes del cliente")
    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonBackReference
    private List<Orden> ordenes = new ArrayList<>();

}
