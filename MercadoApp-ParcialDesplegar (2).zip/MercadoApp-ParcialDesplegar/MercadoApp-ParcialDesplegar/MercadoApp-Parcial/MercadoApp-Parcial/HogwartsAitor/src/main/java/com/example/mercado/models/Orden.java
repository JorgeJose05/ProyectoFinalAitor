package com.example.mercado.models;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;

import lombok.Data;

@Schema(description = "Modelo de Orden")
@Entity
@Data
@Table(name = "Orden")
public class Orden {
    @Schema(description = "Identificador de la orden", example = "1", required = true)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Schema(description = "Fecha de la orden", example = "2021-10-10", required = true)
    private LocalDateTime fecha;
    @Schema(description = "Estado de la orden", example = "En proceso", required = true)
    private String estado;
    @Schema(description = "Total de la orden", example = "100.0", required = true)
    private Double total;

    @Schema(description = "Factura de la orden", required = true)
    @OneToOne(mappedBy = "orden", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private Factura factura;

    @Schema(description = "Cliente de la orden", required = true)
    @ManyToOne
    @JsonManagedReference
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Schema(description = "Productos de la orden", required = true)
    @OneToMany(mappedBy = "orden", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<OrdenProducto> compras = new ArrayList<>();
    


    
}
