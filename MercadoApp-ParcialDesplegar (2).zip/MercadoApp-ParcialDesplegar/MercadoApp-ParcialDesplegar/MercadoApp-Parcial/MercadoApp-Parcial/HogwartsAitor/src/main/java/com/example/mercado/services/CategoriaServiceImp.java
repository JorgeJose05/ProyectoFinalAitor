package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.CategoriaRequestDto;
import com.example.mercado.Dtos.Responses.CategoriaResponseDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.mappers.CategoriaMapper;
import com.example.mercado.models.Categoria;
import com.example.mercado.models.Cliente;
import com.example.mercado.repositories.CategoriaRepository;
import com.fasterxml.jackson.databind.JsonNode;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class CategoriaServiceImp implements CategoriaService{
    private CategoriaRepository categoriaRepository;
    private CategoriaMapper categoriaMapper;

    @Autowired
    public CategoriaServiceImp(CategoriaMapper categoriaMapper,CategoriaRepository categoriaRepository){
        this.categoriaRepository = categoriaRepository;
        this.categoriaMapper = categoriaMapper;
    }
    @Override
    public List<CategoriaResponseDto> getAllCategorias() {
        List<Categoria> categorias = categoriaRepository.findAll();
        return categorias.stream().map(categoriaMapper::toDto).toList();
    }

    @Override
    public CategoriaResponseDto getCategoriaById(Long id) {
        Categoria categoria = categoriaRepository.findById(id).orElse(null);
        return categoriaMapper.toDto(categoria);
    }
    @Override
    public CategoriaResponseDto createCategoria(CategoriaRequestDto categoriaRequestDto) {
       
        Categoria categoria = categoriaMapper.toEntity(categoriaRequestDto);
        Categoria savedCliente = categoriaRepository.save(categoria);
        return categoriaMapper.toDto(savedCliente);
    
    }
    @Override
    public CategoriaResponseDto updateCategoria(Long id, JsonNode categoriaPatchRequestDto) {
        Categoria categoria = categoriaRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Estudiante no encontrado con id: " + id));     

        categoriaMapper.updateEntityFromDto(categoriaPatchRequestDto, categoria);
        Categoria updatedCategoria = categoriaRepository.save(categoria);
        return categoriaMapper.toDto(updatedCategoria);
   
   
    }
    @Override
    @Transactional
    public void deleteCategoria(Long id) {
        Categoria categoria = categoriaRepository.findById(id).orElseThrow(() ->
         new NoSuchElementException("Estudiante no encontrado con id: " + id));
    
        categoriaRepository.delete(categoria);
    }
}
