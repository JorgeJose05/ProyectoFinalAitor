package com.example.mercado.models;

import jakarta.persistence.*;
import lombok.Data;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "ProductoCategoria", description = "ProductoCategoria description")
@Data
@Entity
@Table(name = "productocategoria")
public class ProductoCategoria {

    @Schema(description = "ProductoCategoria id", example = "1")
    @EmbeddedId
    private ProductoCategoriaKey id;

    @Schema(description = "ProductoCategoria producto")
    @ManyToOne
    @MapsId("idProducto")
    @JoinColumn(name = "producto_id")
    @JsonBackReference
    private Producto producto;

    @Schema(description = "ProductoCategoria categoria")
    @ManyToOne
    @MapsId("idCategoria")
    @JoinColumn(name = "categoria_id")
    @JsonManagedReference
    private Categoria categoria;


}
