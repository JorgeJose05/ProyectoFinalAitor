package com.example.mercado.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Requests.ProductoRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.Dtos.Responses.ProductoResponseDto;
import com.example.mercado.models.Producto;
import com.example.mercado.services.ProductoService;
import com.fasterxml.jackson.databind.JsonNode;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("/Mercado/Productos")
@RequiredArgsConstructor
public class ProductoRestController {
    private final ProductoService productoService;

    @Operation(summary = "Operacion para optener todos los productos")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Devuelve una lista de json con todos los productos",
            content = @Content(schema = @Schema(implementation = Producto.class))
    )
    @GetMapping
    public ResponseEntity<List<ProductoResponseDto>> getAllProductos() {
        return ResponseEntity.ok(productoService.getAllProductos());
    }


    
    @Operation(summary = "Operacion para obtener un producto especifico")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Devuelve un producto con el mismo id",
            content = @Content(schema = @Schema(implementation = ProductoResponseDto.class))
    )
    @GetMapping("/{id}")
    public ResponseEntity<ProductoResponseDto> getProductoById(@PathVariable Long id) {
        ProductoResponseDto producto = productoService.getProductoById(id);
        if (producto == null) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
        return ResponseEntity.ok(producto); // 200 OK
    }

    @Operation(summary = "Operacion para crear una producto")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce todos los datos de un producto para crearlo",
            content = @Content(schema = @Schema(implementation = ProductoRequestDto.class))
    )
    @PostMapping
    public ResponseEntity<ProductoResponseDto> createProducto(
            @Valid @RequestBody ProductoRequestDto productoRequestDto) {
        ProductoResponseDto newProducto = productoService.createProducto(productoRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(newProducto);
    }

    @Operation(summary = "Operacion para modificar los campos de un producto")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce los campos que quieres modificar de un producto",
            content = @Content(schema = @Schema(implementation = ProductoRequestDto.class))
    )
    @PatchMapping({ "/{id}" })
    public ResponseEntity<ProductoResponseDto> updatedProducto(@PathVariable Long id,
            @RequestBody JsonNode jsonNode) {
        ProductoResponseDto updatedProducto = productoService.updateProducto(id,
                jsonNode);
        return ResponseEntity.status(HttpStatus.CREATED).body(updatedProducto);
    }

    @Operation(summary = "Operacion para eliminar un producto especifico")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce el id del producto que quieras elieminar"
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProducto(@PathVariable Long id) {
        productoService.deleteProducto(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Operacion para obtener los productos que cuesten mas del valor especificado")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce el minimo de precio que debe tener el producto"
    )
    @GetMapping("/caros/{min}")
    public List<ProductoResponseDto> getProductosCaros(@PathVariable Double min) {
        return productoService.getProductosCaros(min);
    }
}
