package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.CategoriaRequestDto;
import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.CategoriaResponseDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.models.Categoria;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

public interface CategoriaService {
    List<CategoriaResponseDto> getAllCategorias();
    CategoriaResponseDto getCategoriaById(Long id);
    CategoriaResponseDto createCategoria(CategoriaRequestDto categoriaRequestDto);
    CategoriaResponseDto updateCategoria(Long id, JsonNode categoriaPatchRequestDto);

    void deleteCategoria(Long id);
}
