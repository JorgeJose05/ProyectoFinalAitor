package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.mappers.ClienteMapper;
import com.example.mercado.models.Cliente;
import com.example.mercado.repositories.ClienteRespository;
import com.fasterxml.jackson.databind.JsonNode;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ClienteServiceImp implements ClienteService {
    private ClienteRespository clienteRespository;
    private ClienteMapper clienteMapper;

    @Autowired
    public ClienteServiceImp(ClienteRespository clienteRespository, ClienteMapper clienteMapper) {
        this.clienteRespository = clienteRespository;
        this.clienteMapper = clienteMapper;
    }

    @Override
    public List<ClienteResoponseDto> getAllClientes() {
        List<Cliente> clientes = clienteRespository.findAll();
        return clientes.stream().map(clienteMapper::toDto).toList();
    }

    @Override
    public ClienteResoponseDto getClienteById(Long id) {
        Cliente cliente = clienteRespository.findById(id).orElse(null);
        return clienteMapper.toDto(cliente);
    }

    @Override
    public ClienteResoponseDto createCliente(ClienteRequestDto clienteRequestDto) {
        Cliente cliente = clienteMapper.toEntity(clienteRequestDto);
        Cliente savedCliente = clienteRespository.save(cliente);
        return clienteMapper.toDto(savedCliente);

    }

    @Override
    public ClienteResoponseDto updateCliente(Long id, JsonNode clientePatchRequestDto) {
        Cliente cliente = clienteRespository.findById(id).orElseThrow(() -> new NoSuchElementException("Estudiante no encontrado con id: " + id));
        if (cliente == null) {
            return null;
        }
        clienteMapper.updateEntityFromDto(clientePatchRequestDto, cliente);
        Cliente updatedCliente = clienteRespository.save(cliente);
        return clienteMapper.toDto(updatedCliente);
        
    }

    @Override
    @Transactional
    public void deleteCliente(Long id) {
        Cliente existing = clienteRespository.findById(id).orElseThrow(() -> new NoSuchElementException("Estudiante no encontrado con id: " + id));
        clienteRespository.delete(existing);
    }

}
