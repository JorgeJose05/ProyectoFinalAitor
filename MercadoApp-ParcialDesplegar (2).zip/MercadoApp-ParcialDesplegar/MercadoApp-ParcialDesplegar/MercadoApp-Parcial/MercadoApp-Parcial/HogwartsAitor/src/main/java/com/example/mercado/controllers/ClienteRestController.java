package com.example.mercado.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.models.Cliente;
import com.example.mercado.services.ClienteService;
import com.fasterxml.jackson.databind.JsonNode;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("/Mercado/Clientes")
@RequiredArgsConstructor
public class ClienteRestController {
    private final ClienteService clienteService;

    @Operation(summary = "Operacion para obtener todos los cliente")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Devuelve un lista de json con todos los datos de todos los clientes",
            content = @Content(schema = @Schema(implementation = Cliente.class))
    )
    @GetMapping
    public ResponseEntity<List<ClienteResoponseDto>> getAllClients() {
        return ResponseEntity.ok(clienteService.getAllClientes());
    }

    @Operation(summary = "Operacion para obtener un cliente por id")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Devuelve el cliente con el id especificado",
            content = @Content(schema = @Schema(implementation = ClienteResoponseDto.class))
    )
    @GetMapping("/{id}")
    public ResponseEntity<ClienteResoponseDto> getClienteById(@PathVariable Long id) {
        ClienteResoponseDto cliente = clienteService.getClienteById(id);
        if (cliente == null) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
        return ResponseEntity.ok(cliente); // 200 OK
    }

    @Operation(summary = "Operacion para crear un cliente")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introdcir los datos del cliente a crear",
            content = @Content(schema = @Schema(implementation = ClienteRequestDto.class))
    )
    @PostMapping
    public ResponseEntity<ClienteResoponseDto> createCliente(@Valid @RequestBody ClienteRequestDto clienteRequestDto) {
        ClienteResoponseDto newCliente = clienteService.createCliente(clienteRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(newCliente);
    }

    @Operation(summary = "Operacion para modificar campos de un cliente")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Introduce los datos del cliente a modificar",
            content = @Content(schema = @Schema(implementation = ClienteRequestDto.class))
    )
    @PatchMapping({ "/{id}" })
    public ResponseEntity<ClienteResoponseDto> updatedCliente(@PathVariable Long id,
            @RequestBody JsonNode jsonNode) {
        ClienteResoponseDto updatedCliente = clienteService.updateCliente(id,
                jsonNode);
        return ResponseEntity.status(HttpStatus.CREATED).body(updatedCliente);
    }

    @Operation(summary = "Operacion para eliminar un cliente")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "elimina el cliente con el id especificado"
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCliente(@PathVariable Long id) {
        clienteService.deleteCliente(id);
        return ResponseEntity.noContent().build();
    }

}
