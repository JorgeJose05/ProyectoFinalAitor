package com.example.mercado.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.Data;

@Schema(description = "Modelo de Categoria")
@Entity
@Data
@Table(name = "categoria")
public class Categoria {

    @Schema(description = "Identificador de la categoria", example = "1", required = true)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Schema(description = "Nombre de la categoria", example = "Electrodomesticos", required = true)
    private String nombre;

    @Schema(description = "Descripcion de la categoria", example = "Productos electronicos para el hogar", required = true)
    private String descripcion;
    
    @Schema(description = "Productos de la categoria")
    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonBackReference
    private List<ProductoCategoria> productos = new ArrayList<>();

}
