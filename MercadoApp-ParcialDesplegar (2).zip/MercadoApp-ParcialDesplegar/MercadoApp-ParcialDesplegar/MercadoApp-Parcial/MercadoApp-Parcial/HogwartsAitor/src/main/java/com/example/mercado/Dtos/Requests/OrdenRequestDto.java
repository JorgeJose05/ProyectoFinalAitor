package com.example.mercado.Dtos.Requests;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
@Schema(description = "Modelo para hacer request de una orden")
@Data
public class OrdenRequestDto {
    

    @Schema(description = "El total de la orden")
    @NotNull(message = "El total es obligatorio")
    @NotBlank(message = "El total no puede estar vacío")
    @Min(value = -1, message = "El total no puede ser negativo")
    private Double total;

    @Schema(description = "El estado de la orden")
    @NotNull(message = "El estado es obligatorio")
    @NotBlank(message = "El estado no puede estar vacío")
    @Size(max = 50, message = "El estado no puede superar los 50 caracteres")
    private String estado;

    @Schema(description = "La fecha de la orden")
    @NotNull(message = "La fecha es obligatoria")
    @PastOrPresent(message = "La fecha no puede ser en el futuro")
    private LocalDateTime fecha;

    @Schema(description = "El id del cliente")
    @NotNull(message = "El id del cliente es obligatorio")
    @NotBlank(message = "El id del cliente no puede estar vacío")
    private Long clienteId;

}
