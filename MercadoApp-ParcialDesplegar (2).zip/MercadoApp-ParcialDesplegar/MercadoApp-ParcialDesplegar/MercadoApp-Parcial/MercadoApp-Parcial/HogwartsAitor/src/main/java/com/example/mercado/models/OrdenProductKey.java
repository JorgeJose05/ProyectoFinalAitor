package com.example.mercado.models;


import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;

import lombok.Data;

@Schema(description = "Clase que representa la clave compuesta de la tabla ordenproducto")
@Data
@Embeddable
public class OrdenProductKey implements Serializable {
@Schema(description = "Id de la orden", example = "1")
@Column(name = "orden_id")
private Long idOrden;
@Schema(description = "Id del producto", example = "1")
@Column(name = "producto_id")
private Long idProducto;
}
