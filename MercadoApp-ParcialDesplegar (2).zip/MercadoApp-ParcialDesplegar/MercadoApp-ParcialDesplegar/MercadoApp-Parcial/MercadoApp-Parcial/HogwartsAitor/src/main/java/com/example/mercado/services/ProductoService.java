package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Requests.ProductoRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.ProductoResponseDto;
import com.example.mercado.models.Producto;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

public interface ProductoService {
    List<ProductoResponseDto> getAllProductos();

    ProductoResponseDto getProductoById(Long id);

    ProductoResponseDto createProducto(ProductoRequestDto productoRequestDto);

    ProductoResponseDto updateProducto(Long id, JsonNode productoPatchRequestDTO);

    void deleteProducto(Long id);

    List<ProductoResponseDto> getProductosCaros(Double precioMinimo);
}
