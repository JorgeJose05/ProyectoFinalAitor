package com.example.mercado.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.Data;

@Schema(description = "Modelo de Producto")
@Entity
@Data
@Table(name = "Producto")
public class Producto {
    @Schema(description = "Identificador del producto", example = "1", required = true)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Schema(description = "Nombre del producto", example = "Cerveza", required = true)
    private String nombre;
    @Schema(description = "Descripción del producto", example = "Cerveza artesanal", required = true)
    private String descripcion;
    @Schema(description = "Precio del producto", example = "1000", required = true)
    private Double precio;

    @Schema(description = "Cantidad de productos", example = "10", required = true)
    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonBackReference
    private List<OrdenProducto> compras = new ArrayList<>();

    @Schema(description = "Categorias del producto", required = true, example = "Refrescos")
    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ProductoCategoria> categorias = new ArrayList<>();

}
