package com.example.mercado.Dtos.Responses;

import java.time.LocalDateTime;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;


@Data
@Schema(description = "Modelo Factura Response DTO")
public class FacturaResponseDto {
    @Schema(description = "ID de la factura factura", example = "1")
    private Long id;

    @Schema(description = "fecha de la factura", example = "2023-10-01T12:00:00")
    private LocalDateTime fecha;

    @Schema(description = "El total de la factura factura", example = "100.50")
    private double total;

    @Schema(description = "ID de la  order", example = "10")
    private Long ordenId;
}
