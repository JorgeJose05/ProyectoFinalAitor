package com.example.mercado.Dtos.Requests;

import jakarta.validation.constraints.*;
import lombok.Data;

import io.swagger.v3.oas.annotations.media.Schema;
@Schema(description = "Modelo para hacer request de un producto")
@Data
public class ProductoRequestDto {
    
    @Schema(description = "Nombre del producto", example = "Varita")
    @NotNull(message = "El nombre es obligatorio")
    @NotBlank(message = "El nombre no puede estar vacío")
    @Size(max = 50, message = "El nombre no puede superar los 50 caracteres")
    private String nombre;

    @Schema(description = "Descripcion del producto", example = "Varita de saúco")
    @NotNull(message = "La descripcion es obligatorio")
    @NotBlank(message = "La descripcion no puede estar vacío")
    @Size(max = 50, message = "La descripcion no puede superar los 50 caracteres")
    private String descripcion;

    @Schema(description = "Precio del producto", example = "100.0")
    @NotNull(message = "El precio es obligatorio")
    @Min(value = 0, message = "El precio no puede ser negativo")
    private Double precio;



}
