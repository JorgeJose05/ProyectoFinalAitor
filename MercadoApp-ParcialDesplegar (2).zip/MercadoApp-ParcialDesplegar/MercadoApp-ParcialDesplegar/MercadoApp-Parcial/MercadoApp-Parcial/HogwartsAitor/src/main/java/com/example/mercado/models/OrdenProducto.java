package com.example.mercado.models;

import jakarta.persistence.*;
import lombok.Data;

import javax.security.auth.Subject;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;


@Schema(name = "OrdenProducto", description = "Información de la orden de un producto")
@Data
@Entity
@Table(name = "ordenproducto")
public class OrdenProducto {
    @Schema(description = "Identificador de la orden y el producto", example = "1")
    @EmbeddedId
    private OrdenProductKey id;

    @Schema(description = "Orden a la que pertenece el producto")
    @ManyToOne
    @MapsId("idOrden")
    @JoinColumn(name = "orden_id")
    @JsonBackReference
    private Orden orden;


    @Schema(description = "Producto de la orden")
    @ManyToOne
    @MapsId("idProducto")
    @JoinColumn(name = "producto_id")
    @JsonManagedReference
    private Producto producto;

    @Schema(description = "Cantidad de productos", example = "30")
    @Column(name = "cantidad")
    private Integer cantidad;

}
