package com.example.mercado.models;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.Data;

@Schema(description = "Modelo de Factura")
@Entity
@Data
@Table(name = "Factura")
public class Factura {
    @Schema(description = "Identificador de la Factura", example = "1", required = true)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Schema(description = "Cliente de la Factura", required = true)
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonBackReference
    @JoinColumn(name = "orden_id") // La clave foránea debe estar aquí
    private Orden orden;

    @Schema(description = "Fecha de emisión de la Factura", required = true, example = "2023-10-01T12:00:00")
    private LocalDateTime fecha_emision;
    @Schema(description = "Total de la Factura", required = true, example = "23.40")
    private double total;
    

    
}
