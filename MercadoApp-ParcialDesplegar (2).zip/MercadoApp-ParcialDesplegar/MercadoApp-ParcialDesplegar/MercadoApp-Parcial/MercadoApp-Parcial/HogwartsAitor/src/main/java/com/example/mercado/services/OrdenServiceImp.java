package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.mappers.OrdenMapper;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Orden;
import com.example.mercado.repositories.ClienteRespository;
import com.example.mercado.repositories.OrdenRepository;
import com.fasterxml.jackson.databind.JsonNode;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class OrdenServiceImp implements OrdenService {
    private OrdenRepository ordenRepository;
    private OrdenMapper ordenMapper;

    @Autowired
    public OrdenServiceImp(OrdenRepository ordenRepository,OrdenMapper ordenMapper) {
        this.ordenRepository = ordenRepository;
        this.ordenMapper = ordenMapper;
    }

    @Override
    public List<OrdenResponseDto> getAllOrdens() {
        List<Orden> ordenes = ordenRepository.findAll();

        return ordenes.stream().map(ordenMapper::toDto).toList();
    }

    @Override
    public OrdenResponseDto getOrdenById(Long id) {
        Orden orden = ordenRepository.findById(id).orElse(null);
        return ordenMapper.toDto(orden);
    }


    @Override
    public OrdenResponseDto createOrden(OrdenRequestDto ordenRequestDto) {
        Orden orden = ordenMapper.toEntity(ordenRequestDto);
        Orden savedOrden = ordenRepository.save(orden);
        return ordenMapper.toDto(savedOrden);

    }

    @Override
    public OrdenResponseDto updatedOrden(Long id, JsonNode ordenPatchRequestDto) {
        Orden orden = ordenRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Estudiante no encontrado con id: " + id));

        if (orden == null) {
            return null;
        }
        ordenMapper.updateEntityFromDto(ordenPatchRequestDto, orden);
        Orden updatedOrden = ordenRepository.save(orden);
        return ordenMapper.toDto(updatedOrden);
    }

    @Override
    @Transactional
    public void deleteOrdenById(Long id) {
       Orden orden = ordenRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Estudiante no encontrado con id: " + id));
        ordenRepository.delete(orden);
        
    }


}
