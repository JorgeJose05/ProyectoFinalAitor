package com.example.mercado.Dtos.Responses;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Producto Response DTO")
@Data
public class ProductoResponseDto {
    @Schema(description = "Id del producto", example = "1")
    private Long id;
    @Schema(description = "Nombre del producto", example = "Cerveza")
    private String nombre;
    @Schema(description = "Descripcion del producto", example = "Cerveza rubia")
    private String descripcion;
    @Schema(description = "Precio del producto", example = "1.50")
    private Double precio;

    @Schema(description = "Lista de IDs de las compras relacionadas")
    private List<Long> comprasIds; // Solo devuelve los IDs de las compras
    @Schema(description = "Lista de IDs de las categorias relacionadas")
    private List<String> categoriaNombres; // Solo devuelve los IDs de las categorias


}
