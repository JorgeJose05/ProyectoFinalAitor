package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.models.Orden;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

public interface OrdenService {
    List<OrdenResponseDto> getAllOrdens();
    
    OrdenResponseDto getOrdenById(Long id);
    OrdenResponseDto createOrden(OrdenRequestDto ordenRequestDto);
    OrdenResponseDto updatedOrden(Long id, JsonNode ordenPatchRequestDto);
    void deleteOrdenById(Long id);
}
