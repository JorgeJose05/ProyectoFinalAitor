package com.example.mercado.mappers;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Orden;
import com.example.mercado.repositories.OrdenRepository;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class ClienteMapper {

    public ClienteResoponseDto toDto(Cliente cliente) {
        if (cliente == null) {
            return null;
        }
        ClienteResoponseDto dto = new ClienteResoponseDto();

        dto.setId(cliente.getId());
        dto.setNombre(cliente.getNombre());
        dto.setEmail(cliente.getEmail());
        dto.setPassword(cliente.getPassword());
        dto.setDireccion(cliente.getDireccion());
        dto.setTelefono(cliente.getTelefono());
        dto.setOrdenesIds(cliente.getOrdenes().stream().map(orden -> orden.getId()).toList());

        return dto;

    }

    public Cliente toEntity(ClienteRequestDto dto) {
        Cliente cliente = new Cliente();

        cliente.setNombre(dto.getNombre());
        cliente.setEmail(dto.getEmail());
        cliente.setPassword(dto.getPassword());
        cliente.setDireccion(dto.getDireccion());
        cliente.setTelefono(dto.getTelefono());
        cliente.setOrdenes(new ArrayList<>());

        return cliente;
    }

    public void updateEntityFromDto(JsonNode patchJson, Cliente cliente) {
        Map<String, String> errores = new HashMap<>();
        patchJson.fieldNames().forEachRemaining(campo -> {
            switch (campo) {
                case "nombre":
                    if (patchJson.get("nombre").isNull()) {
                        errores.put("nombre", "El campo 'nombre' no puede ser null");
                    } else {
                        String nombre = patchJson.get("nombre").asText();
                        if (nombre.isEmpty())
                            errores.put("nombre", "El campo 'nombre' nopuede estar en blanco null");
                        if (nombre.length() > 50)
                            errores.put("nombre", "El campo 'nombre'no puede superar los 50 caracteres");
                        cliente.setNombre(nombre);
                    }
                    break;
                case "email":
                    if (patchJson.get("email").isNull()) {
                        errores.put("email", "El campo 'email' no puede ser null");
                    } else {
                        String email = patchJson.get("email").asText();
                        if (email.isEmpty())
                            errores.put("email", "El campo 'email' nopuede estar en blanco null");
                        if (email.length() > 50)
                            errores.put("email", "El campo 'email'no puede superar los 50 caracteres");
                        cliente.setEmail(email);
                    }
                    break;
                case "password":
                    if (patchJson.get("password").isNull()) {
                        errores.put("password", "El campo 'password' no puede ser null");
                    } else {
                        String password = patchJson.get("password").asText();
                        if (password.isEmpty())
                            errores.put("password", "El campo 'password' nopuede estar en blanco null");
                        if (password.length() > 50)
                            errores.put("password", "El campo 'password'no puede superar los 50 caracteres");
                        cliente.setPassword(password);
                    }
                    break;
                case "direccion":
                    if (patchJson.get("direccion").isNull()) {
                        errores.put("direccion", "El campo 'direccion' no puede ser null");
                    } else {
                        String direccion = patchJson.get("direccion").asText();
                        if (direccion.isEmpty())
                            errores.put("direccion", "El campo 'direccion' nopuede estar en blanco null");
                        if (direccion.length() > 50)
                            errores.put("direccion", "El campo 'direccion'no puede superar los 50 caracteres");
                        cliente.setDireccion(direccion);
                    }
                    break;
                case "telefono":
                    if (patchJson.get("telefono").isNull()) {
                        errores.put("telefono", "El campo 'telefono' no puede ser null");
                    } else {
                        String telefono = patchJson.get("telefono").asText();
                        if (telefono.isEmpty())
                            errores.put("telefono", "El campo 'telefono' nopuede estar en blanco null");
                        if (telefono.length() > 50)
                            errores.put("telefono", "El campo 'telefono'no puede superar los 50 caracteres");
                        cliente.setTelefono(telefono);
                    }
                    break;

                default:
                    errores.put(campo, "Campo no reconocido: " + campo);
                    break;
            }
        });
        if (!errores.isEmpty()) {
            throw new IllegalArgumentException(String.valueOf(errores));
        }
    }

}
