package com.example.mercado.mappers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Component;

import com.example.mercado.Dtos.Requests.FacturaRequestDto;
import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.FacturaResponseDto;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Factura;
import com.example.mercado.models.Orden;
import com.example.mercado.repositories.OrdenRepository;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class FacturaMapper {
    final OrdenRepository ordenRepository;
    
    public FacturaResponseDto toDto(Factura factura) {
        if (factura == null) {
        return null;
        }
        FacturaResponseDto dto = new FacturaResponseDto();
        
        dto.setId(factura.getId());
        dto.setFecha(factura.getFecha_emision());
        dto.setTotal(factura.getTotal());
        dto.setOrdenId(factura.getOrden().getId());

        return dto;

    }

public Factura toEntity(FacturaRequestDto dto) {
        Orden orden = ordenRepository.findById(dto.getOrdenId())
        .orElseThrow(() -> new NoSuchElementException("Orden no encontrado"));

        Factura factura = new Factura();

        factura.setTotal(dto.getTotal());
        factura.setFecha_emision(dto.getFecha_emision());
        factura.setOrden(orden);


        return factura;
        }


public void updateEntityFromDto(JsonNode patchJson, Factura factura) {
        Map<String, String> errores = new HashMap<>();
        patchJson.fieldNames().forEachRemaining(campo -> {
            switch (campo) {
                case "fecha_emision":
                    if (patchJson.get("fecha_emision").isNull()) {
                        errores.put("fecha_emision", "El campo 'fecha_emision' no puede ser null");
                    } else {
                        try {
                            LocalDateTime fechaEmision = LocalDateTime.parse(patchJson.get("fecha_emision").asText());
                            factura.setFecha_emision(fechaEmision);
                        } catch (Exception e) {
                            errores.put("fecha_emision", "Formato de fecha inválido. Debe ser ISO-8601.");
                        }
                    }
                    break;

                case "total":
                    if (patchJson.get("total").isNull()) {
                        errores.put("total", "El campo 'total' no puede ser null");
                    } else {
                        try {
                            Double total = patchJson.get("total").asDouble();
                            if (total < 0) {
                                errores.put("total", "El campo 'total' no puede ser negativo");
                            }
                            factura.setTotal(total);
                        } catch (Exception e) {
                            errores.put("total", "Valor inválido para 'total'");
                        }
                    }
                    break;

                case "ordenId":
                    if (patchJson.get("ordenId").isNull()) {
                        errores.put("ordenId", "El campo 'ordenId' no puede ser null");
                    } else {
                        Long ordenId = patchJson.get("ordenId").asLong();
                        Orden orden = ordenRepository.findById(ordenId)
                                .orElseThrow(() -> new IllegalArgumentException("Orden no encontrada con ID: " + ordenId));
                        factura.setOrden(orden);
                    }
                    break;

                default:
                    errores.put(campo, "Campo no reconocido: " + campo);
                    break;
            }
        });

        if (!errores.isEmpty()) {
            throw new IllegalArgumentException(String.valueOf(errores));
        }
    }

}
