package com.example.mercado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mercado {

    //Me queda despliege
    public static void main(String[] args) {
        SpringApplication.run(Mercado.class, args);
    }

}
