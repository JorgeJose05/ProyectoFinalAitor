package com.example.mercado.models;


import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;

import lombok.Data;

@Schema(description = "Clase ProductoCategoriaKey")
@Data
@Embeddable
public class ProductoCategoriaKey implements Serializable {
@Schema(description = "Id del producto", example = "1")
@Column(name = "producto_id")
private Long idProducto;
@Schema(description = "Id de la categoria", example = "1")
@Column(name = "categoria_id")
private Long idCategoria;
}
