package com.example.mercado.Dtos.Responses;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ClienteResoponseDto {
    @Schema(example = "1")
    private Long id;

    @Schema(example = "Aitor")
    private String nombre;

    @Schema(example = "email@gmail.com") 
    private String email;

    @Schema(example = "password")
    private String password;
    @Schema(example = "direccion")
    private String direccion;
    @Schema(example = "12344321")
    private String telefono;

    @Schema(example = "1")
    private List<Long> ordenesIds; // Solo devuelve los IDs de las órdenes

}
