package com.example.mercado.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mercado.models.Cliente;

public interface ClienteRespository extends JpaRepository<Cliente, Long> {
}
