package com.example.mercado.mappers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.example.mercado.Dtos.Requests.ProductoRequestDto;
import com.example.mercado.Dtos.Responses.ProductoResponseDto;
import com.example.mercado.models.Producto;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class ProductoMapper {
    public ProductoResponseDto toDto(Producto producto){
 if (producto == null) {
        return null;
        }
        ProductoResponseDto dto = new ProductoResponseDto();
        
        dto.setId(producto.getId());
        dto.setNombre(producto.getNombre());
        dto.setDescripcion(producto.getDescripcion());
        dto.setPrecio(producto.getPrecio());
        dto.setCategoriaNombres(
            producto.getCategorias().stream().map(s -> s.getCategoria().getNombre()).toList()
        );
        dto.setComprasIds(producto.getCompras().stream().map(compra -> compra.getOrden().getId()).toList());



        return dto;
    }

    public Producto toEntity(ProductoRequestDto dto) {
        Producto producto = new Producto();
        
        producto.setNombre(dto.getNombre());
        producto.setDescripcion(dto.getDescripcion());

        producto.setPrecio(dto.getPrecio());
        


        return producto;
        }

public void updateEntityFromDto(JsonNode patchJson, Producto producto) {
        Map<String, String> errores = new HashMap<>();

        patchJson.fieldNames().forEachRemaining(campo -> {
            switch (campo) {
                case "nombre":
                    if (patchJson.get("nombre").isNull()) {
                        errores.put("nombre", "El campo 'nombre' no puede ser null");
                    } else {
                        String nombre = patchJson.get("nombre").asText();
                        if (nombre.isEmpty()) {
                            errores.put("nombre", "El campo 'nombre' no puede estar en blanco");
                        }
                        if (nombre.length() > 50) {
                            errores.put("nombre", "El campo 'nombre' no puede superar los 50 caracteres");
                        }
                        producto.setNombre(nombre);
                    }
                    break;

                case "descripcion":
                    if (patchJson.get("descripcion").isNull()) {
                        errores.put("descripcion", "El campo 'descripcion' no puede ser null");
                    } else {
                        String descripcion = patchJson.get("descripcion").asText();
                        if (descripcion.isEmpty()) {
                            errores.put("descripcion", "El campo 'descripcion' no puede estar en blanco");
                        }
                        if (descripcion.length() > 255) {
                            errores.put("descripcion", "El campo 'descripcion' no puede superar los 255 caracteres");
                        }
                        producto.setDescripcion(descripcion);
                    }
                    break;

                case "precio":
                    if (patchJson.get("precio").isNull()) {
                        errores.put("precio", "El campo 'precio' no puede ser null");
                    } else {
                        try {
                            Double precio = patchJson.get("precio").asDouble();
                            if (precio < 0) {
                                errores.put("precio", "El campo 'precio' no puede ser negativo");
                            }
                            producto.setPrecio(precio);
                        } catch (Exception e) {
                            errores.put("precio", "Valor inválido para 'precio'");
                        }
                    }
                    break;

                default:
                    errores.put(campo, "Campo no reconocido: " + campo);
                    break;
            }
        });

        if (!errores.isEmpty()) {
            throw new IllegalArgumentException("Errores en la actualización: " + errores);
        }
    }



}
