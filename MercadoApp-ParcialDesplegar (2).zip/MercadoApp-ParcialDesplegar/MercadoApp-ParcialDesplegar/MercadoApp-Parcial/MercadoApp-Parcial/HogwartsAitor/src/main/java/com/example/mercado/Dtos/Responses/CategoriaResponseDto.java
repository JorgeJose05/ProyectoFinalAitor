package com.example.mercado.Dtos.Responses;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
@Schema(description = "Categoria Response DTO")
@Data
public class CategoriaResponseDto {
    @Schema(description = "ID de la categoria", example = "1")
    private Long id;
    @Schema(description = "Nombre de la categoria", example = "Electrodomesticos")
    private String nombre;

    @Schema(description = "Descripcion de la categoria", example = "Aparatos electrodomesticos")
    private String descripcion;


    @Schema(description = "Lista de productos de la categoria")
    private List<String> productoNombres; // Solo devuelve los IDs de las categorias


}
