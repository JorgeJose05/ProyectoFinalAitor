package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.FacturaRequestDto;
import com.example.mercado.Dtos.Responses.FacturaResponseDto;
import com.example.mercado.mappers.FacturaMapper;
import com.example.mercado.models.Factura;
import com.example.mercado.models.Orden;
import com.example.mercado.repositories.ClienteRespository;
import com.example.mercado.repositories.FacturaRepository;
import com.example.mercado.repositories.OrdenRepository;
import com.fasterxml.jackson.databind.JsonNode;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class FacturaServiceImp implements FacturaService{
    private FacturaRepository facturaRepository;
    private FacturaMapper facturaMapper;
    private OrdenRepository ordenRepository;

    @Autowired
    public FacturaServiceImp(FacturaRepository facturaRepository,OrdenRepository ordenRepository, FacturaMapper facturaMapper) {
        this.facturaRepository = facturaRepository;
        this.ordenRepository = ordenRepository;
        this.facturaMapper = facturaMapper;
    }
    @Override
    public List<FacturaResponseDto> getAllFacturas() {
        List<Factura> facturas = facturaRepository.findAll();
        return facturas.stream().map(facturaMapper::toDto).toList();
    }
    @Override
    public FacturaResponseDto getFacturaById(Long id) {
      Factura factura = facturaRepository.findById(id).orElse(null);
        return facturaMapper.toDto(factura);
    }
    @Override
    public FacturaResponseDto createFactura(FacturaRequestDto facturaRequestDto) {
        
        // Recuperar la orden por su ID
        Orden orden = ordenRepository.findById(facturaRequestDto.getOrdenId())
                .orElseThrow(() -> new NoSuchElementException("Orden no encontrada"));
                
          // Verificar si ya existe una factura asociada a la orden
    if (orden.getFactura() != null) {
        throw new IllegalStateException("La orden ya tiene una factura asociada.");
    }




        Factura factura = facturaMapper.toEntity(facturaRequestDto);
        factura.setOrden(orden);

        ordenRepository.save(orden);  // Esto asegura que la orden esté persistida.

        Factura savedFactura = facturaRepository.save(factura);
        return facturaMapper.toDto(savedFactura);
    
    }
    @Override
    public FacturaResponseDto updatedFactura(Long id, JsonNode facturaPatchRequestDto) {
       Factura factura = facturaRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Factura no encontrada con id: " + id));
        if (factura == null) {
            return null;
        }
        facturaMapper.updateEntityFromDto(facturaPatchRequestDto, factura);
        Factura updatedFactura = facturaRepository.save(factura);
        return facturaMapper.toDto(updatedFactura);
    
    }
    @Override
    @Transactional
    public void deleteFacturaById(Long id) {
        Factura factura = facturaRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Factura no encontrada con id: " + id));
        facturaRepository.delete(factura);
    }
}
