package com.example.mercado.controllers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.example.mercado.Dtos.Requests.ProductoRequestDto;
import com.example.mercado.Dtos.Responses.ProductoResponseDto;
import com.example.mercado.services.ProductoService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class ProductoRestControllerTest {
    
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductoService productoService;

    @Autowired
    private ObjectMapper objectMapper;

    private ProductoRequestDto postRequestDTO;
    private ProductoResponseDto responseDTO;

    @BeforeEach
    void setUp() {
        postRequestDTO = new ProductoRequestDto();
        postRequestDTO.setNombre("nombre");
        postRequestDTO.setDescripcion("descripcion");
        postRequestDTO.setPrecio(12.0);

        responseDTO = new ProductoResponseDto();
        responseDTO.setNombre("nombre");
        responseDTO.setDescripcion("descripcion");
        responseDTO.setPrecio(12.0);
        responseDTO.setCategoriaNombres(null);
        responseDTO.setComprasIds(null);
        responseDTO.setId(1L);
    }

    @Test
    public void testGetAllProductos() throws Exception {
        List<ProductoResponseDto> productos = new ArrayList<>();
        productos.add(responseDTO);
        when(productoService.getAllProductos()).thenReturn(productos);

        mockMvc.perform(get("/Mercado/Productos"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].nombre").value("nombre"));


    }

    @Test
    public void testGetProductoById()  throws Exception {
        Long productoId = 1L;
        when(productoService.getProductoById(productoId)).thenReturn(responseDTO);

        mockMvc.perform(get("/Mercado/Productos/{id}", productoId)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(productoId))
                .andExpect(jsonPath("$.nombre").value("nombre"));
    }

    @Test
    public void testCreateProducto()  throws Exception {
        when(productoService.createProducto(any(ProductoRequestDto.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/Mercado/Productos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(postRequestDTO)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.nombre").value("nombre"));

    }

    @Test
    public void testUpdateProducto()  throws Exception {
        Long productoId = 1L;
        JsonNode updateData = objectMapper.createObjectNode().put("descripcion", "asdfasdf");
        responseDTO.setDescripcion("asdfasdf");
        when(productoService.updateProducto(eq(productoId), any(JsonNode.class))).thenReturn(responseDTO);

        mockMvc.perform(patch("/Mercado/Productos/{id}", productoId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updateData.toString()))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.descripcion").value("asdfasdf"));


    }

    @Test
    public void testDeleteProducto() throws Exception {
        Long clienteID = 1L;

        mockMvc.perform(delete("/Mercado/Productos/{id}", clienteID))
                .andExpect(status().isNoContent());
    }


    
}
