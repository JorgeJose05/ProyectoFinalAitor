package com.example.mercado.repositories;

import com.example.mercado.models.Cliente;

import jakarta.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class ClienteRepositoryTest {


    // Inyección de repositorios
    @Autowired
    private ClienteRespository clienteRespository;

    // Datos de prueba
    private Cliente cliente;

    @BeforeEach
    void setUp() {
        cliente = new Cliente();
        cliente.setNombre("nombretest");
        cliente.setDireccion("direcciontest");
        cliente.setEmail("emailtest");
        cliente.setPassword("conttest");
        cliente.setTelefono("123456");
        //cliente.setId(1L);

    }


    @Test
    void testSaveCliente() {

        Cliente savedCliente = clienteRespository.save(cliente);
        assertNotNull(savedCliente.getId(),"El cliente debe tener un Id asignado");
        assertEquals("nombretest", savedCliente.getNombre(),"El nombre del cliente guardado debe coincidir con el esperado");
    }

    @Test
    void testFindClienteById() {
        clienteRespository.save(cliente);
        Cliente foundcliente = clienteRespository.findById(cliente.getId()).orElse(null);

        assertNotNull(foundcliente, "El cliente debe ser encontrado por su ID");
        assertEquals(cliente.getNombre(), foundcliente.getNombre(), "El id del cliente encontrado debe coincidir con el esperado");

    }

    @Test
    void testUpdateCliente() {
        clienteRespository.save(cliente);

        Cliente toUpdate = clienteRespository.findById(cliente.getId()).orElse(null);
        toUpdate.setNombre("NombreActualizado");
        clienteRespository.save(toUpdate);

        Cliente updated = clienteRespository.findById(toUpdate.getId()).orElse(null);
        assertEquals("NombreActualizado", updated.getNombre(), "El nombre del cliente debe ser actualizado");

    }

    @Test
    void testDeleteCliente() {
        clienteRespository.save(cliente);

        clienteRespository.delete(cliente);

        Cliente deleted = clienteRespository.findById(cliente.getId()).orElse(null);
        assertNull(deleted,"El cliente debe ser eliminado y no encontrado en la base de datos" );
    }

    @Test
    void testFindAllClientes() {
        Cliente cliente1 = new Cliente();
        cliente1.setNombre("Nombre1");
        cliente1.setEmail("Email1");
        cliente1.setTelefono("1234656");
        cliente1.setDireccion("calle1");
        cliente1.setPassword("password1");
        clienteRespository.save(cliente1);


        Cliente cliente2 = new Cliente();
        cliente2.setNombre("Nombre2");
        cliente2.setEmail("Email2");
        cliente2.setTelefono("2234656");
        cliente2.setDireccion("calle2");
        cliente2.setPassword("password2");
        clienteRespository.save(cliente2);

        Cliente cliente3 = new Cliente();
        cliente3.setNombre("Nombre3");
        cliente3.setEmail("Email3");
        cliente3.setTelefono("3334656");
        cliente3.setDireccion("calle3");
        cliente3.setPassword("password3");
        clienteRespository.save(cliente3);

        // When: Obtenemos todos los profesores de la base de datos
        List<Cliente> clientes = clienteRespository.findAll();

        // Then: Debe devolver una lista con todos los profesores
        assertEquals(3, clientes.size(), "Debe devolver tres clientes");
        assertTrue(clientes.contains(cliente1), "La lista debe contener al cliente 1");
        assertTrue(clientes.contains(cliente2), "La lista debe contener al cliente 2");
        assertTrue(clientes.contains(cliente3), "La lista debe contener al cliente 3");





    }














}
