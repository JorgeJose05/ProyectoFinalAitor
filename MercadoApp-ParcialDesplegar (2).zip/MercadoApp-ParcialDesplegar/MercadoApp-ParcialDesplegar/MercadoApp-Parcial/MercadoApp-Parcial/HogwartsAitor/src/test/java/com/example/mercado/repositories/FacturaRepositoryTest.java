package com.example.mercado.repositories;

import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDateTime;
import java.util.List;


import com.example.mercado.models.Factura;
import com.example.mercado.models.Factura;
import com.example.mercado.models.Orden;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class FacturaRepositoryTest {
    

    // Inyección de repositorios
    @Autowired
    private FacturaRepository FacturaRespository;

    // Datos de prueba
    private Factura factura;

    @BeforeEach
    void setUp() {
        factura = new Factura();
        factura.setTotal(1234);
        factura.setOrden(new Orden());
        factura.setFecha_emision(LocalDateTime.now());
        //factura.setId(1L);


    }


    @Test
    void testSaveFactura() {

        Factura savedFactura = FacturaRespository.save(factura);
        assertNotNull(savedFactura.getId(),"La Factura debe tener un Id asignado");
        assertEquals(factura.getFecha_emision().toString(), savedFactura.getFecha_emision().toString(),"La fecha de la Factura guardado debe coincidir con el esperado");
    }

    @Test
    void testFindFacturaById() {
        FacturaRespository.save(factura);
        Factura foundFactura = FacturaRespository.findById(factura.getId()).orElse(null);

        assertNotNull(foundFactura, "El Factura debe ser encontrado por su ID");
        assertEquals(factura.getFecha_emision().toString(), foundFactura.getFecha_emision().toString(), "La fecha de la factura encontrado debe coincidir con el esperado");

    }

    @Test
    void testUpdateFactura() {
        FacturaRespository.save(factura);

        Factura toUpdate = FacturaRespository.findById(factura.getId()).orElse(null);
        toUpdate.setTotal(1234);
        FacturaRespository.save(toUpdate);

        Factura updated = FacturaRespository.findById(toUpdate.getId()).orElse(null);
        assertEquals(1234, updated.getTotal(), "El total del Factura debe ser actualizado");

    }

    @Test
    void testDeleteFactura() {
        FacturaRespository.save(factura);

        FacturaRespository.delete(factura);

        Factura deleted = FacturaRespository.findById(factura.getId()).orElse(null);
        Assertions.assertNull( deleted, "La Factura debe ser eliminada y no encontrada en la base de datos");
    }

    @Test
    void testFindAllFacturas() {
        Factura Factura1 = new Factura();
        Factura1.setFecha_emision(LocalDateTime.now());
        Factura1.setTotal(1234);
        FacturaRespository.save(Factura1);


        Factura Factura2 = new Factura();
        Factura2.setFecha_emision(LocalDateTime.now());
        Factura2.setTotal(1234);
        FacturaRespository.save(Factura2);

        
        Factura Factura3 = new Factura();
        Factura3.setFecha_emision(LocalDateTime.now());
        Factura3.setTotal(1234);
        FacturaRespository.save(Factura3);

        // When: Obtenemos todos los profesores de la base de datos
        List<Factura> Facturas = FacturaRespository.findAll();

        // Then: Debe devolver una lista con todos los profesores
        assertEquals(3, Facturas.size(), "Debe devolver tres Facturas");
        assertTrue(Facturas.contains(Factura1), "La lista debe contener al Factura 1");
        assertTrue(Facturas.contains(Factura2), "La lista debe contener al Factura 2");
        assertTrue(Facturas.contains(Factura3), "La lista debe contener al Factura 3");


}
}