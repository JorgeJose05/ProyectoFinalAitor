package com.example.mercado.repositories;

import com.example.mercado.models.Cliente;
import com.example.mercado.models.Factura;
import com.example.mercado.models.Orden;
import com.example.mercado.models.Producto;

import jakarta.transaction.Transactional;

import org.antlr.v4.runtime.atn.SemanticContext.OR;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class OrdenRepositoryTest {


    // Inyección de repositorios
    @Autowired
    private OrdenRepository ordenRepository;

    // Datos de prueba
    private Orden orden;

    @BeforeEach
    void setUp() {
        orden = new Orden();
        orden.setTotal(1234.4);
        orden.setFecha(LocalDateTime.now());
        orden.setEstado("estadotest");
        orden.setCliente(new Cliente());
        orden.setCompras(new ArrayList<>());
        orden.setFactura(new Factura());

    }


    @Test
    void testSaveOrden() {

        Orden savedOrden = ordenRepository.save(orden);
        assertNotNull(savedOrden.getId(),"El orden debe tener un Id asignado");
        assertEquals("estadotest", savedOrden.getEstado(),"El estado del orden guardado debe coincidir con el esperado");
    }

    @Test
    void testFindOrdenById() {
        ordenRepository.save(orden);
        Orden foundOrden = ordenRepository.findById(orden.getId()).orElse(null);

        assertNotNull(foundOrden, "El orden debe ser encontrado por su ID");
        assertEquals(orden.getEstado(), foundOrden.getEstado(), "El estado del orden encontrado debe coincidir con el esperado");

    }

    @Test
    void testUpdateOrden() {
        ordenRepository.save(orden);

        Orden toUpdate = ordenRepository.findById(orden.getId()).orElse(null);
        toUpdate.setEstado("EstadoActualizado");
        ordenRepository.save(toUpdate);

        Orden updated = ordenRepository.findById(toUpdate.getId()).orElse(null);
        assertEquals("EstadoActualizado", updated.getEstado(), "El estado del orden debe ser actualizado");

    }

    @Test
    void testDeleteOrden() {
        ordenRepository.save(orden);

        ordenRepository.delete(orden);

        Orden deleted = ordenRepository.findById(orden.getId()).orElse(null);
        assertNull(deleted,"El orden debe ser eliminado y no encontrado en la base de datos" );
    }

    @Test
    void testFindAllOrden() {
        ordenRepository.flush();
        Orden orden1 = new Orden();
        orden1.setTotal(1234.4);
        orden1.setFecha(LocalDateTime.now());
        orden1.setEstado("estadotest");
        ordenRepository.save(orden1);


        Orden orden2 = new Orden();
        orden2.setTotal(1234.4);
        orden2.setFecha(LocalDateTime.now());
        orden2.setEstado("estadotest");
        orden2.setCompras(new ArrayList<>());
        ordenRepository.save(orden2);


        
        Orden orden3 = new Orden();
        orden3.setTotal(1234.4);
        orden3.setFecha(LocalDateTime.now());
        orden3.setEstado("estadotest");
        orden3.setCompras(new ArrayList<>());
        ordenRepository.save(orden3);

        //ordenRepository.flush();

        List<Orden> ordenes = ordenRepository.findAll();

        // Then: Debe devolver una lista con todos los profesores
        assertEquals(3, ordenes.size(), "Debe devolver tres ordenes");
        assertTrue(ordenes.contains(orden1), "La lista debe contener la orden 1");
        assertTrue(ordenes.contains(orden2), "La lista debe contener la orden 2");
        assertTrue(ordenes.contains(orden3), "La lista debe contener la orden 3");





    }


}

