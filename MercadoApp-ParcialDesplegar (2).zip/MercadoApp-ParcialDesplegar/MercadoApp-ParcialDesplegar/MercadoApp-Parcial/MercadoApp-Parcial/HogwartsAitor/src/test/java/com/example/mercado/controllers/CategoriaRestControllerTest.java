package com.example.mercado.controllers;


import com.example.mercado.Dtos.Requests.CategoriaRequestDto;
import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.CategoriaResponseDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.services.CategoriaService;
import com.example.mercado.services.ClienteService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class CategoriaRestControllerTest {
    

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CategoriaService categoriaService;

    @Autowired
    private ObjectMapper objectMapper;

    private CategoriaRequestDto postRequestDTO;
    private CategoriaResponseDto responseDTO;

    @BeforeEach
    void setUp() {
        postRequestDTO = new CategoriaRequestDto();
        postRequestDTO.setNombre("nombre");
        postRequestDTO.setDescripcion("descripcion");

        responseDTO = new CategoriaResponseDto();
        responseDTO.setId(1L);
        responseDTO.setNombre("nombre");
        responseDTO.setDescripcion("descripcion");

    }

    @Test
    public void testGetAllCategorias() throws Exception {
        List<CategoriaResponseDto> categorias = new ArrayList<>();
        categorias.add(responseDTO);
        when(categoriaService.getAllCategorias()).thenReturn(categorias);

        mockMvc.perform(get("/Mercado/Categorias"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].nombre").value("nombre"));


    }

    @Test
    public void testGetCategoriaById()  throws Exception {
        Long categoriaId = 1L;
        when(categoriaService.getCategoriaById(categoriaId)).thenReturn(responseDTO);

        mockMvc.perform(get("/Mercado/Categorias/{id}", categoriaId)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(categoriaId))
                .andExpect(jsonPath("$.nombre").value("nombre"));
    }

    @Test
    public void testCreateCliente()  throws Exception {
        when(categoriaService.createCategoria(any(CategoriaRequestDto.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/Mercado/Categorias")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(postRequestDTO)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.nombre").value("nombre"));

    }

    @Test
    public void testUpdateCategoria()  throws Exception {
        Long categoriaId = 1L;
        JsonNode updateData = objectMapper.createObjectNode().put("nombre", "12344321");
        responseDTO.setNombre("12344321");
        when(categoriaService.updateCategoria(eq(categoriaId), any(JsonNode.class))).thenReturn(responseDTO);

        mockMvc.perform(patch("/Mercado/Categorias/{id}", categoriaId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updateData.toString()))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.nombre").value("12344321"));


    }

    @Test
    public void testDeleteCategoria() throws Exception {
        Long categoriaId = 1L;

        mockMvc.perform(delete("/Mercado/Categorias/{id}", categoriaId))
                .andExpect(status().isNoContent());
    }


    
}
