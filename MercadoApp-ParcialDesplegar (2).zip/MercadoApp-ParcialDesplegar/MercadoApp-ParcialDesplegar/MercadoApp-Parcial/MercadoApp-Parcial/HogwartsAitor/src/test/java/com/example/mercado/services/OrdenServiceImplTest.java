package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.mappers.OrdenMapper;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Factura;
import com.example.mercado.models.Orden;
import com.example.mercado.repositories.OrdenRepository;
import com.example.mercado.services.OrdenServiceImp;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.ConstraintViolationException;

import org.aspectj.weaver.ast.Or;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrdenServiceImplTest {

    @Mock
    private OrdenRepository ordenRepository;
    
    @Mock
    private OrdenMapper ordenMapper;

    @InjectMocks
    private OrdenServiceImp ordenService;  

    private Orden orden;
    private OrdenResponseDto ordenResponseDto;
    private OrdenRequestDto ordenRequestDto;

 @BeforeEach
    void setUp() {
        orden = new Orden();

        orden.setId(1L);
        orden.setEstado("estado");
        orden.setFecha(LocalDateTime.now());
        orden.setTotal(199.0);
        orden.setCompras(new ArrayList<>());

    
        ordenResponseDto = new OrdenResponseDto();
        ordenResponseDto.setId(1L);
        ordenResponseDto.setEstado("estado");
        ordenResponseDto.setFecha(LocalDateTime.now());
        ordenResponseDto.setTotal(199.0);
        

        ordenRequestDto = new OrdenRequestDto();

        ordenRequestDto.setEstado("estado");
        ordenRequestDto.setFecha(LocalDateTime.now());
        ordenRequestDto.setTotal(199.0);


    
    }

    @Test
    public void getAllOrdenes() {
        List<Orden> ordenes = Arrays.asList(orden);
        List<OrdenResponseDto> ordenResponseDtos = Arrays.asList(ordenResponseDto);

        when(ordenRepository.findAll()).thenReturn(ordenes);
        when(ordenMapper.toDto(orden)).thenReturn(ordenResponseDto);

        List<OrdenResponseDto> result = ordenService.getAllOrdens();

        assertEquals(ordenResponseDtos, result);
    }

    @Test
    public void getOrdenById() {
        when(ordenRepository.findById(1L)).thenReturn(Optional.of(orden));
        when(ordenMapper.toDto(orden)).thenReturn(ordenResponseDto);

        OrdenResponseDto result = ordenService.getOrdenById(1L);

        assertEquals(ordenResponseDto, result);
    }

    @Test
    public void createOrden() {
        when(ordenMapper.toEntity(ordenRequestDto)).thenReturn(orden);
        when(ordenRepository.save(orden)).thenReturn(orden);
        when(ordenMapper.toDto(orden)).thenReturn(ordenResponseDto);

        OrdenResponseDto result = ordenService.createOrden(ordenRequestDto);

        assertEquals(ordenResponseDto, result);
    }

    @Test
    public void updateOrden() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(ordenRepository.findById(1L)).thenReturn(Optional.of(orden));
        when(ordenMapper.toDto(orden)).thenReturn(ordenResponseDto);
        when(ordenRepository.save(orden)).thenReturn(orden);

        OrdenResponseDto result = ordenService.updatedOrden(1L, jsonNode);

        assertEquals(ordenResponseDto, result);
    }

    @Test
    public void deleteOrden() {
        when(ordenRepository.findById(1L)).thenReturn(Optional.of(orden));

        ordenService.deleteOrdenById(1L);

        verify(ordenRepository).delete(orden);
    }

    @Test
    public void deleteOrdenNotFound() {
        when(ordenRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> ordenService.deleteOrdenById(1L));
        }
        
        @Test
        public void updateOrdenTestNotFound() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(ordenRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> ordenService.updatedOrden(1L, jsonNode));
        verify(ordenRepository).findById(1L);
        }

        @Test
        public void deleteOrdenTestNotFound() {
        when(ordenRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> ordenService.deleteOrdenById(1L));
        verify(ordenRepository).findById(1L);
        }

        @Test
        public void updateOrdenInvalidPatch() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(ordenRepository.findById(1L)).thenReturn(Optional.of(orden));
        when(ordenMapper.toDto(orden)).thenReturn(ordenResponseDto);
        when(ordenRepository.save(orden)).thenReturn(orden);

        OrdenResponseDto result = ordenService.updatedOrden(1L, jsonNode);

        assertEquals(ordenResponseDto, result);
        verify(ordenRepository).findById(1L);
        verify(ordenMapper).toDto(orden);
        verify(ordenRepository).save(orden);
        }

    @Test
    public void createOrdenInvalid() {
        when(ordenMapper.toEntity(ordenRequestDto)).thenReturn(orden);
        when(ordenRepository.save(orden)).thenThrow(ConstraintViolationException.class);

        assertThrows(ConstraintViolationException.class, () -> ordenService.createOrden(ordenRequestDto));
    }


    
}
