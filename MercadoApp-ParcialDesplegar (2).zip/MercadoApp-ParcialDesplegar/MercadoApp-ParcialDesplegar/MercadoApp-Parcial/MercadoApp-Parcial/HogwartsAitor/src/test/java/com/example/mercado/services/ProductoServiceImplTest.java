package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ProductoRequestDto;
import com.example.mercado.Dtos.Responses.ProductoResponseDto;
import com.example.mercado.mappers.ProductoMapper;
import com.example.mercado.models.Producto;
import com.example.mercado.repositories.ProductoRepository;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ProductoServiceImplTest {

    @Mock
    private ProductoRepository productoRepository;
    
    @Mock
    private ProductoMapper productoMapper;

    @InjectMocks
    private ProductoServiceImp productoService;

    private Producto producto;
    private ProductoResponseDto productoResponseDto;
    private ProductoRequestDto productoRequestDto;

    @BeforeEach
    public void setUp() {
        producto = new Producto();
        producto.setId(1L);
        producto.setNombre("nombrepro");
        producto.setDescripcion("descpro");
        producto.setPrecio(23.3);

        productoResponseDto = new ProductoResponseDto();
        productoResponseDto.setId(1L);
        productoResponseDto.setDescripcion("descpro");
        productoResponseDto.setNombre("nombrepro");
        productoResponseDto.setDescripcion("descpro");

        productoRequestDto = new ProductoRequestDto();
        productoRequestDto.setDescripcion("descpro");
        productoRequestDto.setNombre("nombrepro");
        productoRequestDto.setPrecio(23.3);
    }

    @Test
    public void getAllProductosTest(){
        List<Producto> productos = Arrays.asList(producto);
        when(productoRepository.findAll()).thenReturn(productos);
        when(productoMapper.toDto(any(Producto.class))).thenReturn(productoResponseDto);

        List<ProductoResponseDto> result = productoService.getAllProductos();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        verify(productoRepository).findAll();
        verify(productoMapper, times(productos.size())).toDto(any(Producto.class));
    }

    @Test
    public void getProductoByIdTest(){
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        when(productoMapper.toDto(any(Producto.class))).thenReturn(productoResponseDto);

        ProductoResponseDto result = productoService.getProductoById(1L);

        assertNotNull(result);
        assertEquals("nombrepro", result.getNombre());
        verify(productoRepository).findById(1L);
        verify(productoMapper).toDto(any(Producto.class));
    }

    @Test
    public void createProductoTest(){
        when(productoMapper.toEntity(any(ProductoRequestDto.class))).thenReturn(producto);
        when(productoRepository.save(any(Producto.class))).thenReturn(producto);
        when(productoMapper.toDto(any(Producto.class))).thenReturn(productoResponseDto);

        ProductoResponseDto result = productoService.createProducto(productoRequestDto);

        assertNotNull(result);
        assertEquals("nombrepro", result.getNombre());
        verify(productoMapper).toEntity(any(ProductoRequestDto.class));
        verify(productoRepository).save(any(Producto.class));
        verify(productoMapper).toDto(any(Producto.class));
    }

    @Test
    public void updateProductoTest() {
        JsonNode patch = Mockito.mock(JsonNode.class);
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        doNothing().when(productoMapper).updateEntityFromDto(any(JsonNode.class), any(Producto.class));
        when(productoRepository.save(any(Producto.class))).thenReturn(producto);
        when(productoMapper.toDto(any(Producto.class))).thenReturn(productoResponseDto);

        ProductoResponseDto result = productoService.updateProducto(1L, patch);

        assertNotNull(result);
        assertEquals("nombrepro", result.getNombre());
        verify(productoRepository).findById(1L);
        verify(productoMapper).updateEntityFromDto(any(JsonNode.class), any(Producto.class));
        verify(productoRepository).save(any(Producto.class));
    }

    @Test
    public void deleteProductoByIdTest() {
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        doNothing().when(productoRepository).delete(any(Producto.class));

        productoService.deleteProducto(1L);

        verify(productoRepository).findById(1L);
        verify(productoRepository).delete(any(Producto.class));
    }

    @Test
    public void updateProductoInvalidDataTest() {
        JsonNode patch = Mockito.mock(JsonNode.class);
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        doThrow(IllegalArgumentException.class).when(productoMapper).updateEntityFromDto(any(JsonNode.class), any(Producto.class));

        assertThrows(IllegalArgumentException.class, () -> {
            productoService.updateProducto(1L, patch);
        });

        verify(productoRepository).findById(1L);
        verify(productoMapper).updateEntityFromDto(any(JsonNode.class), any(Producto.class));
        verify(productoRepository, never()).save(any(Producto.class));
    }

    @Test
    public void deleteProductoByIdNotFoundTest() {
        when(productoRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> {
            productoService.deleteProducto(1L);
        });

        verify(productoRepository).findById(1L);
        verify(productoRepository, never()).delete(any(Producto.class));
    }

    @Test
    public void createProductoInvalidDataTest() {
        ProductoRequestDto invalidDto = new ProductoRequestDto();
        invalidDto.setNombre("");
        invalidDto.setDescripcion("VeryLongSurnameThatExceedsTheMaximumAllowedCharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

        when(productoMapper.toEntity(any(ProductoRequestDto.class)))
                .thenThrow(new ConstraintViolationException("Datos inválidos", null));

        assertThrows(ConstraintViolationException.class, () -> {
            productoService.createProducto(invalidDto);
        });

        verify(productoMapper).toEntity(any(ProductoRequestDto.class));
        verify(productoRepository, never()).save(any(Producto.class));
    }
}
