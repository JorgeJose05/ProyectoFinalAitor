package com.example.mercado.controllers;


import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.services.ClienteService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class ClienteRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClienteService clienteService;

    @Autowired
    private ObjectMapper objectMapper;

    private ClienteRequestDto postRequestDTO;
    private ClienteResoponseDto responseDTO;

    @BeforeEach
    void setUp() {
        postRequestDTO = new ClienteRequestDto();
        postRequestDTO.setNombre("nombre");
        postRequestDTO.setDireccion("direccion");
        postRequestDTO.setEmail("email");
        postRequestDTO.setPassword("passwrd");
        postRequestDTO.setTelefono("123456778");

        responseDTO = new ClienteResoponseDto();
        responseDTO.setId(1L);
        responseDTO.setDireccion("direccion");
        responseDTO.setPassword("passwed");
        responseDTO.setNombre("nombre");
        responseDTO.setEmail("email");
        responseDTO.setTelefono("12344321");

    }

    @Test
    public void testGetAllClientes() throws Exception {
        List<ClienteResoponseDto> clientes = new ArrayList<>();
        clientes.add(responseDTO);
        when(clienteService.getAllClientes()).thenReturn(clientes);

        mockMvc.perform(get("/Mercado/Clientes"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].nombre").value("nombre"));


    }

    @Test
    public void testGetClienteById()  throws Exception {
        Long clienteID = 1L;
        when(clienteService.getClienteById(clienteID)).thenReturn(responseDTO);

        mockMvc.perform(get("/Mercado/Clientes/{id}", clienteID)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(clienteID))
                .andExpect(jsonPath("$.nombre").value("nombre"));
    }

    @Test
    public void testCreateCliente()  throws Exception {
        when(clienteService.createCliente(any(ClienteRequestDto.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/Mercado/Clientes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(postRequestDTO)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.nombre").value("nombre"));

    }

    @Test
    public void testUpdateCliente()  throws Exception {
        Long clienteID = 1L;
        JsonNode updateData = objectMapper.createObjectNode().put("telefono", "12344321");
        responseDTO.setTelefono("12344321");
        when(clienteService.updateCliente(eq(clienteID), any(JsonNode.class))).thenReturn(responseDTO);

        mockMvc.perform(patch("/Mercado/Clientes/{id}", clienteID)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updateData.toString()))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.telefono").value("12344321"));


    }

    @Test
    public void testDeleteCliente() throws Exception {
        Long clienteID = 1L;

        mockMvc.perform(delete("/Mercado/Clientes/{id}", clienteID))
                .andExpect(status().isNoContent());
    }


    
}