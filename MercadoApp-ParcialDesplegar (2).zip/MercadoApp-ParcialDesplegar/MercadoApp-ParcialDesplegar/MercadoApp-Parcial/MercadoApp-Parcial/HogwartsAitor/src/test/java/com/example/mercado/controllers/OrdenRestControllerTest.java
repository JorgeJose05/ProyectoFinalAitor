package com.example.mercado.controllers;


import com.example.mercado.Dtos.Requests.OrdenRequestDto;
import com.example.mercado.Dtos.Responses.OrdenResponseDto;
import com.example.mercado.services.ClienteService;
import com.example.mercado.services.OrdenService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class OrdenRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrdenService ordenService;

    @Autowired
    private ObjectMapper objectMapper;

    private OrdenRequestDto postRequestDTO;
    private OrdenResponseDto responseDTO;

    @BeforeEach
    void setUp() {
        postRequestDTO = new OrdenRequestDto();
        postRequestDTO.setEstado("confirmada");
        postRequestDTO.setFecha(LocalDateTime.of(1999, 12, 3, 3, 3, 3));
        postRequestDTO.setTotal(23.0);
        
        postRequestDTO.setClienteId(4L);
        

        responseDTO = new OrdenResponseDto();
        responseDTO.setId(1L);
        responseDTO.setEstado("confirmada");
        responseDTO.setFecha(LocalDateTime.of(1999, 12, 3, 3, 3, 3));
        responseDTO.setTotal(23.0);
        responseDTO.setClienteId(1L);
        responseDTO.setFacturaId(1L);
        responseDTO.setComprasIds(null);
        
    }

    @Test
    public void testGetAllOrdenes() throws Exception {
        List<OrdenResponseDto> ordenes = new ArrayList<>();
        ordenes.add(responseDTO);
        when(ordenService.getAllOrdens()).thenReturn(ordenes);

        mockMvc.perform(get("/Mercado/Orden"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].estado").value("confirmada"));


    }

    @Test
    public void testGetOrdenById()  throws Exception {
        Long ordenId = 1L;
        when(ordenService.getOrdenById(ordenId)).thenReturn(responseDTO);

        mockMvc.perform(get("/Mercado/Orden/{id}", ordenId)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(ordenId))
                .andExpect(jsonPath("$.estado").value("confirmada"));
    }

    @Test
    public void testCreateOrden()  throws Exception {
        when(ordenService.createOrden(any(OrdenRequestDto.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/Mercado/Orden")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(postRequestDTO)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.estado").value("confirmada"));

    }

    @Test
    public void testUpdateOrden()  throws Exception {
        Long ordenId = 1L;
        JsonNode updateData = objectMapper.createObjectNode().put("total", 23.5);
        responseDTO.setTotal(23.5);
        when(ordenService.updatedOrden(eq(ordenId), any(JsonNode.class))).thenReturn(responseDTO);

        mockMvc.perform(patch("/Mercado/Orden/{id}", ordenId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updateData.toString()))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.total").value(23.5));


    }

    @Test
    public void testDeleteOrden() throws Exception {
        Long ordenId = 1L;

        mockMvc.perform(delete("/Mercado/Orden/{id}", ordenId))
                .andExpect(status().isNoContent());
    }


    
}