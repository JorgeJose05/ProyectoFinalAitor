package com.example.mercado.repositories;

import com.example.mercado.models.Categoria;

import jakarta.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class CategoriaRepositoryTest {


    // Inyección de repositorios
    @Autowired
    private CategoriaRepository categoriaRepository;

    // Datos de prueba
    private Categoria categoria;

    @BeforeEach
    void setUp() {
        categoria = new Categoria();
        categoria.setDescripcion("desctest");
        categoria.setNombre("nombretest");
        categoria.setProductos(new ArrayList<>());

        //cliente.setId(1L);

    }


    @Test
    void testSaveCategoria() {

        Categoria savedCategoria = categoriaRepository.save(categoria);
        assertNotNull(savedCategoria.getId(),"La categoria debe tener un Id asignado");
        assertEquals("nombretest", savedCategoria.getNombre(),"El nombre de la categoria guardado debe coincidir con el esperado");
    }

    @Test
    void testFindCategoriaById() {
        categoriaRepository.save(categoria);
        Categoria foundCategoira = categoriaRepository.findById(categoria.getId()).orElse(null);

        assertNotNull(foundCategoira, "La categoria debe ser encontrado por su ID");
        assertEquals(categoria.getNombre(), foundCategoira.getNombre(), "El nombre de la categoria encontrada debe coincidir con el esperado");

    }

    @Test
    void testUpdateCategoria() {
        categoriaRepository.save(categoria);

        Categoria toUpdate = categoriaRepository.findById(categoria.getId()).orElse(null);
        toUpdate.setNombre("NombreActualizado");
        categoriaRepository.save(toUpdate);

        Categoria updated = categoriaRepository.findById(toUpdate.getId()).orElse(null);
        assertEquals("NombreActualizado", updated.getNombre(), "El nombre de la categoria debe ser actualizado");

    }

    @Test
    void testDeleteCategoria() {
        categoriaRepository.save(categoria);

        categoriaRepository.delete(categoria);

        Categoria deleted = categoriaRepository.findById(categoria.getId()).orElse(null);
        assertNull(deleted,"La categoria debe ser eliminado y no encontrado en la base de datos" );
    }

    @Test
    void testFindAllCategoira() {
        Categoria categoria1 = new Categoria();
        categoria1.setDescripcion("descc");
        categoria1.setNombre("aasdf");
        categoria1.setProductos(new ArrayList<>());
        categoriaRepository.save(categoria1);

        
        Categoria categoria2 = new Categoria();
        categoria2.setDescripcion("descc");
        categoria2.setNombre("aasdf");
        categoria2.setProductos(new ArrayList<>());
        categoriaRepository.save(categoria2);

        
        Categoria categoria3 = new Categoria();
        categoria3.setDescripcion("descc");
        categoria3.setNombre("aasdf");
        categoria3.setProductos(new ArrayList<>());
        categoriaRepository.save(categoria3);

        categoriaRepository.flush();

        // When: Obtenemos todos los profesores de la base de datos
        List<Categoria> categorias = categoriaRepository.findAll();

        // Then: Debe devolver una lista con todos los profesores
        assertEquals(3, categorias.size(), "Debe devolver tres clientes");
        assertTrue(categorias.contains(categoria1), "La lista debe contener la categoria 1");
        assertTrue(categorias.contains(categoria2), "La lista debe contener la categoira 2");
        assertTrue(categorias.contains(categoria3), "La lista debe contener la categoria 3");



    }



}

