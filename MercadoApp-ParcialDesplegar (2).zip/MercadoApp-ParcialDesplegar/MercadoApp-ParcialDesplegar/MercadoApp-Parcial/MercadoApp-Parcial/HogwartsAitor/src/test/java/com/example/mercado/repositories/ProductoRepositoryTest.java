package com.example.mercado.repositories;

import com.example.mercado.models.Producto;

import jakarta.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class ProductoRepositoryTest {


    // Inyección de repositorios
    @Autowired
    private ProductoRepository productoRepository;

    // Datos de prueba
    private Producto producto;

    @BeforeEach
    void setUp() {
        producto = new Producto();
        producto.setCategorias(new ArrayList<>());
        producto.setNombre("nombretest");
        producto.setPrecio(1234.0);
        producto.setDescripcion("descpro");
        producto.setCompras(new ArrayList<>());
        

    }


    @Test
    void testSaveProducto() {

        Producto savedProducto = productoRepository.save(producto);
        assertNotNull(savedProducto.getId(),"El cliente debe tener un Id asignado");
        assertEquals("nombretest", savedProducto.getNombre(),"El nombre del producto guardado debe coincidir con el esperado");
    }

    @Test
    void testFindProductoById() {
        productoRepository.save(producto);
        Producto foundProducto = productoRepository.findById(producto.getId()).orElse(null);

        assertNotNull(foundProducto, "El producto debe ser encontrado por su ID");
        assertEquals(producto.getNombre(), foundProducto.getNombre(), "El nombre del producto encontrado debe coincidir con el esperado");

    }

    @Test
    void testUpdateProducto() {
        productoRepository.save(producto);

        Producto toUpdate = productoRepository.findById(producto.getId()).orElse(null);
        toUpdate.setNombre("NombreActualizado");
        productoRepository.save(toUpdate);

        Producto updated = productoRepository.findById(toUpdate.getId()).orElse(null);
        assertEquals("NombreActualizado", updated.getNombre(), "El nombre del producto debe ser actualizado");

    }

    @Test
    void testDeleteProducto() {
        productoRepository.save(producto);

        productoRepository.delete(producto);

        Producto deleted = productoRepository.findById(producto.getId()).orElse(null);
        assertNull(deleted,"El producto debe ser eliminado y no encontrado en la base de datos" );
    }

    @Test
    void testFindAllClientes() {
        Producto producto1 = new Producto();
        producto1.setNombre("Nombre1");
        producto1.setPrecio(1234.0);
        producto1.setDescripcion("descripcion");
        producto1.setCategorias(new ArrayList<>());
        producto1.setCompras(new ArrayList<>());
        productoRepository.save(producto1);


        Producto producto2 = new Producto();
        producto2.setNombre("Nombre1");
        producto2.setPrecio(1234.0);
        producto2.setDescripcion("descripcion");
        producto2.setCategorias(new ArrayList<>());
        producto2.setCompras(new ArrayList<>());
        productoRepository.save(producto2);



        Producto producto3 = new Producto();
        producto3.setNombre("Nombre1");
        producto3.setPrecio(1234.0);
        producto3.setDescripcion("descripcion");
        producto3.setCategorias(new ArrayList<>());
        producto3.setCompras(new ArrayList<>());
        productoRepository.save(producto3);


        // When: Obtenemos todos los profesores de la base de datos
        List<Producto> productos = productoRepository.findAll();

        // Then: Debe devolver una lista con todos los profesores
        assertEquals(3, productos.size(), "Debe devolver tres clientes");
        assertTrue(productos.contains(producto1), "La lista debe contener el orden 1");
        assertTrue(productos.contains(producto2), "La lista debe contener el orden 2");
        assertTrue(productos.contains(producto3), "La lista debe contener el orden 3");





    }














}

