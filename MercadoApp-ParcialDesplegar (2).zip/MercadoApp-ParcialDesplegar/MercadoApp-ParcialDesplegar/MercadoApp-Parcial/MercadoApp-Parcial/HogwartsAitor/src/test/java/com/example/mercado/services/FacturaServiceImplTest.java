package com.example.mercado.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.mercado.Dtos.Requests.FacturaRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.FacturaResponseDto;
import com.example.mercado.mappers.FacturaMapper;
import com.example.mercado.models.Cliente;
import com.example.mercado.models.Factura;
import com.example.mercado.models.Orden;
import com.example.mercado.repositories.FacturaRepository;
import com.example.mercado.repositories.OrdenRepository;
import com.example.mercado.services.FacturaServiceImp;
import com.fasterxml.jackson.databind.JsonNode;

import jakarta.validation.ConstraintViolationException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FacturaServiceImplTest {
    
    @Mock
    private OrdenRepository ordenRepository;
    @Mock
    private FacturaRepository facturaRepository;

    @Mock
    private FacturaMapper facturaMapper;

    @InjectMocks
    private FacturaServiceImp facturaService;

    private Factura factura;
    private FacturaResponseDto facturaResponseDto;
    private FacturaRequestDto facturaRequestDto;

 @BeforeEach
    void setUp() {
        factura = new Factura();

        factura.setId(1L);
        factura.setFecha_emision(LocalDateTime.now());
        factura.setTotal(50);

        facturaResponseDto = new FacturaResponseDto();
        facturaResponseDto.setId(1L);
        facturaResponseDto.setFecha(LocalDateTime.now());
        facturaResponseDto.setTotal(50);
        
        facturaRequestDto = new FacturaRequestDto();
        facturaRequestDto.setFecha_emision(LocalDateTime.now());
        facturaRequestDto.setTotal(50.0);
        facturaRequestDto.setOrdenId(1L);


}

    @Test
    public void getAllFacturasTest() {
        List<Factura> facturas = Arrays.asList(factura);
        when(facturaRepository.findAll()).thenReturn(facturas);
        when(facturaMapper.toDto(factura)).thenReturn(facturaResponseDto);

        List<FacturaResponseDto> result = facturaService.getAllFacturas();

        assertEquals(1, result.size());
        assertEquals(facturaResponseDto, result.get(0));
    }

    @Test
    public void updatedFacturaTest() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(facturaRepository.findById(1L)).thenReturn(Optional.of(factura));
        when(facturaMapper.toDto(factura)).thenReturn(facturaResponseDto);
        when(facturaRepository.save(factura)).thenReturn(factura);

        FacturaResponseDto result = facturaService.updatedFactura(1L, jsonNode);

        assertEquals(facturaResponseDto, result);
        verify(facturaRepository).findById(1L);
        verify(facturaMapper).toDto(factura);
        verify(facturaRepository).save(factura);
    }

    @Test
    public void createFacturaTest() {
        Orden ordenMock = new Orden();
    when(ordenRepository.findById(anyLong())).thenReturn(Optional.of(ordenMock)); 
    
    when(facturaMapper.toEntity(facturaRequestDto)).thenReturn(factura);
    when(facturaRepository.save(factura)).thenReturn(factura);
    when(facturaMapper.toDto(factura)).thenReturn(facturaResponseDto);


    FacturaResponseDto result = facturaService.createFactura(facturaRequestDto);

    assertNotNull(result);
    assertEquals(facturaResponseDto.getId(), result.getId());
    assertEquals(facturaResponseDto.getTotal(), result.getTotal());
    
    verify(facturaMapper).toEntity(facturaRequestDto);
    verify(facturaRepository).save(factura);
    verify(facturaMapper).toDto(factura);
    verify(ordenRepository).findById(anyLong()); 
    }

    @Test
    public void getFacturaById() {
        when(facturaRepository.findById(1L)).thenReturn(Optional.of(factura));
        when(facturaMapper.toDto(factura)).thenReturn(facturaResponseDto);

        FacturaResponseDto result = facturaService.getFacturaById(1L);

        assertEquals(facturaResponseDto, result);
        verify(facturaRepository).findById(1L);
        verify(facturaMapper).toDto(factura);
    }

    @Test
    public void deleteFacturaTest() {
        when(facturaRepository.findById(1L)).thenReturn(Optional.of(factura));
        facturaService.deleteFacturaById(1L);
        verify(facturaRepository).findById(1L);
        verify(facturaRepository).delete(factura);
    }

    @Test
    public void deleteFacturaTestNotFound() {
        when(facturaRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(NoSuchElementException.class, () -> facturaService.deleteFacturaById(1L));
        verify(facturaRepository).findById(1L);
        verify(facturaRepository, never()).delete(factura);
    }

    @Test
    public void updateFacturaTestNotFound() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(facturaRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> facturaService.updatedFactura(1L, jsonNode));
        verify(facturaRepository).findById(1L);
        verify(facturaMapper, never()).toDto(factura);
        verify(facturaRepository, never()).save(factura);
    }









}