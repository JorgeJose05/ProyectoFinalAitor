package com.example.mercado.controllers;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Requests.FacturaRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.Dtos.Responses.FacturaResponseDto;
import com.example.mercado.services.ClienteService;
import com.example.mercado.services.FacturaService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;





@SpringBootTest
@AutoConfigureMockMvc
public class FacturaRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FacturaService facturaService;

    @Autowired
    private ObjectMapper objectMapper;

    private FacturaRequestDto postRequestDTO;
    private FacturaResponseDto responseDTO;

    @BeforeEach
    void setUp() {
        postRequestDTO = new FacturaRequestDto();
        postRequestDTO.setFecha_emision(LocalDateTime.of(1,1 , 10, 1, 10,10));
        postRequestDTO.setTotal(12.3);
        postRequestDTO.setOrdenId(1L);

        responseDTO = new FacturaResponseDto();
        responseDTO.setFecha(LocalDateTime.of(1,1 , 10, 1, 10,10));
        responseDTO.setTotal(12.3);
        responseDTO.setId(1L);
        responseDTO.setOrdenId(1L);

    }

    @Test
    public void testGetAllFacturas() throws Exception {
        List<FacturaResponseDto> facturas = new ArrayList<>();
        facturas.add(responseDTO);
        when(facturaService.getAllFacturas()).thenReturn(facturas);

        mockMvc.perform(get("/Mercado/Factura"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].total").value(12.3));


    }

    @Test
    public void testGetFacturaById()  throws Exception {
        Long facturaId = 1L;
        when(facturaService.getFacturaById(facturaId)).thenReturn(responseDTO);

        mockMvc.perform(get("/Mercado/Factura/{id}", facturaId)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(facturaId))
                .andExpect(jsonPath("$.total").value(12.3));
    }

    @Test
    public void testCreateFactura()  throws Exception {
        when(facturaService.createFactura(any(FacturaRequestDto.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/Mercado/Factura")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(postRequestDTO)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.total").value(12.3));

    }

    @Test
    public void testUpdateFactura()  throws Exception {
        Long facturaId = 1L;
        JsonNode updateData = objectMapper.createObjectNode().put("total", 33.3);
        responseDTO.setTotal(33.3);
        when(facturaService.updatedFactura(eq(facturaId), any(JsonNode.class))).thenReturn(responseDTO);

        mockMvc.perform(patch("/Mercado/Factura/{id}", facturaId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updateData.toString()))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.total").value(33.3));


    }

    @Test
    public void testDeleteCliente() throws Exception {
        Long facturaId = 1L;

        mockMvc.perform(delete("/Mercado/Factura/{id}", facturaId))
                .andExpect(status().isNoContent());
    }


}
