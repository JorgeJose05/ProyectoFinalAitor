package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.CategoriaRequestDto;
import com.example.mercado.Dtos.Responses.CategoriaResponseDto;
import com.example.mercado.mappers.CategoriaMapper;
import com.example.mercado.models.Categoria;
import com.example.mercado.repositories.CategoriaRepository;
import com.example.mercado.repositories.CategoriaRepository;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CategoriaServiceImplTest {

    @Mock
    private CategoriaRepository categoriaRepository;

    @Mock
    private CategoriaMapper categoriaMapper;

    @InjectMocks
    private CategoriaServiceImp categoriaService;

    private Categoria categoria;
    private CategoriaResponseDto categoriaResponseDto;
    private CategoriaRequestDto categoriaRequestDto;

    @BeforeEach
    public void setUp(){

        categoria = new Categoria();
        categoria.setNombre("nomcat");
        categoria.setDescripcion("desccat");
        categoria.setId(1L);

        categoriaResponseDto = new CategoriaResponseDto();
        categoriaResponseDto.setNombre("nomcat");
        categoriaResponseDto.setDescripcion("desccat");
        categoriaResponseDto.setId(1L);

        categoriaRequestDto = new CategoriaRequestDto();
        categoriaRequestDto.setNombre("nomcat");
        categoriaRequestDto.setDescripcion("desccat");

    }


    @Test
    public void getAllCategoriasTest() {
        List<Categoria> categorias = Arrays.asList(categoria);
        when(categoriaRepository.findAll()).thenReturn(categorias);
        when(categoriaMapper.toDto(any(Categoria.class))).thenReturn(categoriaResponseDto);

        List<CategoriaResponseDto> result = categoriaService.getAllCategorias();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        verify(categoriaRepository).findAll();
        verify(categoriaMapper, times(categorias.size())).toDto(any(Categoria.class));
    }
    @Test
    public void getCategoriaByIdTest() {
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(categoria));
        when(categoriaMapper.toDto(any(Categoria.class))).thenReturn(categoriaResponseDto);

        CategoriaResponseDto result = categoriaService.getCategoriaById(1L);

        assertNotNull(result);
        assertEquals("nomcat", result.getNombre());
        verify(categoriaRepository).findById(1L);
        verify(categoriaMapper).toDto(any(Categoria.class));
    }


    @Test
    public void createCategoriaTest() {
        when(categoriaMapper.toEntity(any(CategoriaRequestDto.class))).thenReturn(categoria);
        when(categoriaRepository.save(any(Categoria.class))).thenReturn(categoria);
        when(categoriaMapper.toDto(any(Categoria.class))).thenReturn(categoriaResponseDto);

        CategoriaResponseDto result = categoriaService.createCategoria(categoriaRequestDto);

        assertNotNull(result);
        assertEquals("nomcat", result.getNombre());
        verify(categoriaMapper).toEntity(any(CategoriaRequestDto.class));
        verify(categoriaRepository).save(any(Categoria.class));
        verify(categoriaMapper).toDto(any(Categoria.class));
    }

    @Test
    public void updateCategoriaTest() {
        JsonNode patch = Mockito.mock(JsonNode.class);
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(categoria));
        doNothing().when(categoriaMapper).updateEntityFromDto(any(JsonNode.class), any(Categoria.class));
        when(categoriaRepository.save(any(Categoria.class))).thenReturn(categoria);
        when(categoriaMapper.toDto(any(Categoria.class))).thenReturn(categoriaResponseDto);

        CategoriaResponseDto result = categoriaService.updateCategoria(1L, patch);

        assertNotNull(result);
        assertEquals("nomcat", result.getNombre());
        verify(categoriaRepository).findById(1L);
        verify(categoriaMapper).updateEntityFromDto(any(JsonNode.class), any(Categoria.class));
        verify(categoriaRepository).save(any(Categoria.class));
    }


    @Test
    public void deleteCategoriaByIdTest() {
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(categoria));
        doNothing().when(categoriaRepository).delete(any(Categoria.class));

        categoriaService.deleteCategoria(1L);

        verify(categoriaRepository).findById(1L);
        verify(categoriaRepository).delete(any(Categoria.class));
    }


    @Test
    public void updateCategoriaInvalidDataTest() {
        JsonNode patch = Mockito.mock(JsonNode.class);
        when(categoriaRepository.findById(1L)).thenReturn(Optional.of(categoria));
        doThrow(IllegalArgumentException.class).when(categoriaMapper).updateEntityFromDto(any(JsonNode.class), any(Categoria.class));

        assertThrows(IllegalArgumentException.class, () -> {
            categoriaService.updateCategoria(1L, patch);
        });

        verify(categoriaRepository).findById(1L);
        verify(categoriaMapper).updateEntityFromDto(any(JsonNode.class), any(Categoria.class));
        verify(categoriaRepository, never()).save(any(Categoria.class));
    }

    @Test
    public void deleteCategoriaByIdNotFoundTest() {
        when(categoriaRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> {
            categoriaService.deleteCategoria(1L);
        });

        verify(categoriaRepository).findById(1L);
        verify(categoriaRepository, never()).delete(any(Categoria.class));
    }

    @Test
    public void createCategoriaInvalidDataTest() {
        CategoriaRequestDto invalidDto = new CategoriaRequestDto();
        invalidDto.setNombre("");
        invalidDto.setDescripcion("VeryLongSurnameThatExceedsTheMaximumAllowedCharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

        when(categoriaMapper.toEntity(any(CategoriaRequestDto.class)))
                .thenThrow(new ConstraintViolationException("Datos inválidos", null));

        assertThrows(ConstraintViolationException.class, () -> {
            categoriaService.createCategoria(invalidDto);
        });

        verify(categoriaMapper).toEntity(any(CategoriaRequestDto.class));
        verify(categoriaRepository, never()).save(any(Categoria.class));
    }


}
