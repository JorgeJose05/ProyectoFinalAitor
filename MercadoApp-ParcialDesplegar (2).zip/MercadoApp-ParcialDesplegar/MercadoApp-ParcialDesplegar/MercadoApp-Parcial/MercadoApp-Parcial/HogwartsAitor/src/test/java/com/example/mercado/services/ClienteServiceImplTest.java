package com.example.mercado.services;

import com.example.mercado.Dtos.Requests.ClienteRequestDto;
import com.example.mercado.Dtos.Responses.ClienteResoponseDto;
import com.example.mercado.mappers.ClienteMapper;
import com.example.mercado.models.Cliente;
import com.example.mercado.repositories.ClienteRespository;
import com.example.mercado.services.ClienteServiceImp;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ClienteServiceImplTest {
    




    @Mock
    private ClienteRespository clienteRespository;
    
    @Mock
    private ClienteMapper clienteMapper;

    @InjectMocks
    private ClienteServiceImp clienteService;


    private Cliente cliente;
    private ClienteResoponseDto clienteResponseDto;
    private ClienteRequestDto clienteRequestDto;

    @BeforeEach
    void setUp() {
        cliente = new Cliente();

        cliente.setId(1L);
        cliente.setNombre("Harry");
        cliente.setEmail("email");
        cliente.setPassword("password");
        cliente.setDireccion("direccion");
        cliente.setTelefono("telefono");

    
        clienteResponseDto = new ClienteResoponseDto();
        clienteResponseDto.setId(1L);
        clienteResponseDto.setNombre("John");
        clienteResponseDto.setEmail("email");
        clienteResponseDto.setDireccion("direccion");
        clienteResponseDto.setPassword("null");
        clienteResponseDto.setTelefono("12342341");
        

        clienteRequestDto = new ClienteRequestDto();
        clienteRequestDto.setNombre("John");
        clienteRequestDto.setEmail("email");
        clienteRequestDto.setPassword("null");
        clienteRequestDto.setDireccion("direccion");
        clienteRequestDto.setTelefono("12344311");
   

    
    }

    @Test
    public void getAllClientesTest() {
        List<Cliente> clientes = Arrays.asList(cliente);
        List<ClienteResoponseDto> clienteResponseDtos = Arrays.asList(clienteResponseDto);

        when(clienteRespository.findAll()).thenReturn(clientes);
        when(clienteMapper.toDto(cliente)).thenReturn(clienteResponseDto);

        List<ClienteResoponseDto> result = clienteService.getAllClientes();

        assertEquals(clienteResponseDtos, result);
        verify(clienteRespository).findAll();
        verify(clienteMapper).toDto(cliente);
    }

    @Test
    public void getClienteById() {
        when(clienteRespository.findById(1L)).thenReturn(Optional.of(cliente));
        when(clienteMapper.toDto(cliente)).thenReturn(clienteResponseDto);

        ClienteResoponseDto result = clienteService.getClienteById(1L);

        assertEquals(clienteResponseDto, result);
        verify(clienteRespository).findById(1L);
        verify(clienteMapper).toDto(cliente);
    }

    @Test
    public void createClienteTest() {
        when(clienteMapper.toEntity(clienteRequestDto)).thenReturn(cliente);
        when(clienteRespository.save(cliente)).thenReturn(cliente);
        when(clienteMapper.toDto(cliente)).thenReturn(clienteResponseDto);

        ClienteResoponseDto result = clienteService.createCliente(clienteRequestDto);

        assertEquals(clienteResponseDto, result);
        verify(clienteMapper).toEntity(clienteRequestDto);
        verify(clienteRespository).save(cliente);
        verify(clienteMapper).toDto(cliente);
    }

    @Test
    public void updateClienteTest() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(clienteRespository.findById(1L)).thenReturn(Optional.of(cliente));
        when(clienteMapper.toDto(cliente)).thenReturn(clienteResponseDto);
        when(clienteRespository.save(cliente)).thenReturn(cliente);

        ClienteResoponseDto result = clienteService.updateCliente(1L, jsonNode);

        assertEquals(clienteResponseDto, result);
        verify(clienteRespository).findById(1L);
        verify(clienteMapper).toDto(cliente);
        verify(clienteRespository).save(cliente);
    }


    @Test
    public void updateClienteTestNotFound() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(clienteRespository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> clienteService.updateCliente(1L, jsonNode));
        verify(clienteRespository).findById(1L);
        verify(clienteMapper, never()).toDto(cliente);
        verify(clienteRespository, never()).save(cliente);
    }

    @Test
    public void deleteClienteTest() {
        when(clienteRespository.findById(1L)).thenReturn(Optional.of(cliente));

        clienteService.deleteCliente(1L);

        verify(clienteRespository).findById(1L);
        verify(clienteRespository).delete(cliente);
    }

    @Test
    public void deleteClienteTestNotFound() {
        when(clienteRespository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> clienteService.deleteCliente(1L));
        verify(clienteRespository).findById(1L);
        verify(clienteRespository, never()).delete(cliente);
    }

    @Test
    public void updateClienteInvalidPatch() {
        JsonNode jsonNode = Mockito.mock(JsonNode.class);
        when(clienteRespository.findById(1L)).thenReturn(Optional.of(cliente));
        doThrow(ConstraintViolationException.class).when(clienteMapper).updateEntityFromDto(jsonNode, cliente);

        assertThrows(ConstraintViolationException.class, () -> clienteService.updateCliente(1L, jsonNode));
        verify(clienteRespository).findById(1L);
        verify(clienteMapper).updateEntityFromDto(jsonNode, cliente);
        verify(clienteRespository, never()).save(cliente);
    }

    @Test
    public void createClienteInvalid() {
        when(clienteMapper.toEntity(clienteRequestDto)).thenReturn(cliente);
        when(clienteRespository.save(cliente)).thenThrow(ConstraintViolationException.class);

        assertThrows(ConstraintViolationException.class, () -> clienteService.createCliente(clienteRequestDto));
        verify(clienteMapper).toEntity(clienteRequestDto);
        verify(clienteRespository).save(cliente);
        verify(clienteMapper, never()).toDto(cliente);
    }





}
